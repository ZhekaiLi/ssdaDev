function [] = add_paths()
%ADD_PATHS  Add paths to the required libraries
%
% John R. Owen, NCRG, 7 May 2009
% Shahzad Mumtaz, NCRG, 07 February 2011
%
% This code will work with both Linux and Windows.
% Before compiling dvms, call this function so paths are added
% and compiler knows where to find dvms's functions.

h1=fullfile(pwd,'DVMS_Classes');
addpath(h1,'-begin');

h1=fullfile(pwd,'DVMS_Libraries');
addpath(genpath(h1),'-begin');

% Add current directory as a special case
addpath(pwd);



