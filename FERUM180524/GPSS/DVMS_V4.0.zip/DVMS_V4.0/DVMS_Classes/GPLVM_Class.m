classdef GPLVM_Class < NL_Model_Cls
    %   GPLVM_Model 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    %   Copyright (C) Yigit Yildirim, 2011
    
    properties
        OutPut  % OutPut structure variable to hold the model type and projection output
        options2
        options3
    end
    
    methods
        % Constructor method to initialize instance variables
        function handles=GPLVM_Class()
            Model_Cls();
            handles.OutPut.ModelType='GPLVM';
        end
        
       % Get Methods to retrieve different members of the output structure
        
        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        
        function ModelType=GetModelType(hObject)
            ModelType=hObject.OutPut.ModelType;
        end
        
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errorlog;
        end
        
        
        % Set Methods to set algorithms parameters
        
        function hObject=SetOPtions2(hObject,OP)
            hObject.options2.iter=OP(1);
            hObject.options2.app_Alg = OP(2);
            hObject.options2.back_Cons = OP(3);
            
        end
        
        % Computes and projects the data on the specified dimensions
        function  hObject=Train_GPLVM(hObject,handles)
            randn('seed', 1e5);
            rand('seed', 1e5);
            
            switch hObject.options2.app_Alg
                case 1
                    approx = 'pitc';
                case 2
                    approx = 'fitc';
                case 3
                    approx = 'ptc';
                case 4
                    approx = 'ftc';
                case 5
                    approx = 'dtc';
                case 6
                    approx = 'dtcvar';
            end
            
            hObject.options3 = fgplvmOptions(approx);
            hObject.options3.optimiser = 'scg';
            
            switch hObject.options2.back_Cons
                case 1
                    hObject.options3.back = 'mlp';
                    hObject.options3.backOptions = mlpOptions;
                case 2
                    hObject.options3.back = 'kbr';
                    hObject.options3.backOptions = kbrOptions(handles.Data.GetValues());
                    hObject.options3.backOptions.kern = kernCreate(handles.Data.GetValues(), 'rbf');
                    hObject.options3.backOptions.kern.inverseWidth = 0.00001;
            end
            
            
            
            
            hObject.OutPut.latentDim = 2;
            hObject.OutPut.d = size(handles.Data.GetValues(), 2);            
                       
            val = handles.Data.GetValues();
            hObject.OutPut.model = fgplvmCreate(hObject.OutPut.latentDim, hObject.OutPut.d, val, hObject.options3);
            % Optimise the model
            iters = hObject.options2.iter;
            display = 1;
            
            [hObject.OutPut.model errorlg scalelg] = fgplvmOptimise(hObject.OutPut.model, display, iters);
            hObject.OutPut.errorlog = errorlg;
            
            hObject=hObject.SetTrainingStatus(true);            
            hObject.OutPut.y=hObject.OutPut.model.X;
        end
        
        % Project data on the trained model
        function hObject=Test_GPLVM(hObject,handles,dim_latent)
            Y = handles.Data.GetValues();
            X = zeros(size(Y, 1), hObject.OutPut.model.q);
            temp = modelOut(hObject.OutPut.model.back, Y);
            mal = hObject.OutPut.model.X;
            a = hObject.OutPut.model;
            testsize = size(Y,1);
            for i = 1:size(Y, 1)               
                llVec = fgplvmPointLogLikelihood(hObject.OutPut.model, temp, repmat(Y(i, :), testsize , 1));                
                [void, ind] = max(llVec);
                X(i, :) = temp(ind, :);
                
            end
            for i =1:size(X, 1)
                Xc(i, :) = fgplvmOptimisePoint(hObject.OutPut.model, X(i, :), Y(i, :), 0, 100);
                
            end
            hObject.OutPut.y= Xc;            
        end
        
      
        
        
        function hObject=Save_As(hObject,DataFile)
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_gplvm.mat'];
            TitleString=['Save As (use "', '_gpvlm.mat','" file extension'];
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
        end
        
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_gplvm.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
            
        end       
    end
end

