classdef GTM_Model_Cls < GTMGen_Model_Cls
    %   GTM_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011    
    
    properties
        OutPut  % OutPut structure variable to hold the model type and projection output
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function handles=GTM_Model_Cls()
            GTMGen_Model_Cls();
            handles.OutPut.ModelType='GTM';
        end
        
        % Set methods to assign the values of the class member variables
        function hObject=SetModelType(hObject,MT)
            hObject.OutPut.ModelType=MT;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure
        function MT=GetModelType(hObject)
            MT=hObject.OutPut.ModelType;
        end
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        %  Function to train GTM Model for the given dataset
        function hObject = Train_GTM(hObject, handles)
            %TRAIN_GTM  Train GTM model
            %
            % John R. Owen, NCRG, Aston University, 29 Jul 2009
            %
            %
            % Output:
            % net2      trained network structure
            % y         array of points to be plotted
            % errlog    log (array) of training errors
            % Modified  Shahzad Mumtaz to make it compatible with the object oriented version of DVMS
            
            fprintf('\nTraining GTM model\n');
            
            % Repeat results
            reset_random();
            
            % Dataset parameters
            x = handles.Data.GetValues();                   % Load the dataset
            [xr, xc] = size(x);             % No. rows, no. columns in dataset
            
            % -----------------
            % Init. gtm network
            % -----------------
            
            latgrid = [hObject.No_Latent_Rows, hObject.No_Latent_Rows];         % Latent-space grid layout
            rbfgrid = [hObject.No_RBF_Centres, hObject.No_RBF_Centres];         % RBF-centre grid layout
            latp = prod(latgrid);           % No. latent-space points
            rbfc = prod(rbfgrid);           % No. of RBF centres
            
            
            % Set up gtm network
            hObject.OutPut.net1 = gtm(hObject.Latent_Dim, latp, xc, rbfc, 'gaussian', hObject.PWIV);
            
            % Init. gtm network
            
            hObject.OutPut.net1 = gtminit(hObject.OutPut.net1, hObject.Options1, x, 'regular', latgrid, rbfgrid);
            
            
            % -----------------
            % Train gtm network
            % -----------------
            
            
            
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = gtmem(hObject.OutPut.net1, x, hObject.Options2);
            
            
            % Get coords for plotting
            hObject.OutPut.y = gtmlmean(hObject.OutPut.net2, x);
            hObject=hObject.SetTrainingStatus(true);
            
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_GTM(hObject, handles)
            x = handles.Data.GetValues();                   % Load the dataset
            hObject.OutPut.y = gtmlmean(hObject.OutPut.net2, x);
        end
        
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_gtm.mat'];
            TitleString=['Save As (use "', '_gtm.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
            
        end
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_gtm.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
        end
        
    end
end

