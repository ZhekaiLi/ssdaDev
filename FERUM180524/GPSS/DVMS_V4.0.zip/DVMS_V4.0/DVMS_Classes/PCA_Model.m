classdef PCA_Model < Model_Cls
    %   PCA_Model 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    
    properties
        OutPut  % OutPut structure variable to hold the model type and projection output
    end
    
    methods
        % Constructor method to initialize instance variables
        function handles=PCA_Model()
            Model_Cls();
            handles.OutPut.ModelType='PCA';
        end
        
        % Compute the eigen vectors and eigen values for the given dataset
        function hObject=Init_PCA(hObject,handles)
            [hObject.OutPut.PCVals hObject.OutPut.PCVecs]=pca(handles.Data.GetValues());
        end
        
        % Projects the data on specified number of projected dimensions
        function hObject=Project_PCA(hObject,handles,dim_latent)
            hObject.OutPut.y=(handles.Data.Values-ones(size(handles.Data.Values,1),1)*mean(handles.Data.Values))*(hObject.OutPut.PCVecs(:,1:dim_latent));
        end
        
        % Computes and projects the data on the specified dimensions
        function  hObject=Train_PCA(hObject,handles,dim)
            hObject=hObject.Init_PCA(handles);
            hObject=hObject.Project_PCA(handles,dim);
            hObject=hObject.SetTrainingStatus(true);
        end
        
        % Project data on the trained model
        function hObject=Test_PCA(hObject,handles,dim_latent)
            hObject.OutPut.y=(handles.Data.Values-ones(size(handles.Data.Values,1),1)*mean(handles.Data.Values))*(hObject.OutPut.PCVecs(:,1:dim_latent));
        end
        
        % Get Methods to retrieve different members of the output structure
        function PCVals=GetPCVals(hObject)
            PCVals=hObject.OutPut.PCVals;
        end
        
        function PCVecs=GetPCVecs(hObject)
            PCVecs=hObject.OutPut.PCVecs;
        end
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ModelType=GetModelType(hObject)
            ModelType=hObject.OutPut.ModelType;
        end
        
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_pca.mat'];
            TitleString=['Save As (use "', '_pca.mat','" file extension'];            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);            
        end
        
        % Method to load saved trained model 
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_pca.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
            
        end
    end
end

