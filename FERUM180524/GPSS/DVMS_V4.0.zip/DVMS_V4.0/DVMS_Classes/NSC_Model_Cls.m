classdef NSC_Model_Cls < NL_Model_Cls 
    %   NSC_Model_Cls 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        Options2            % Training Algorithms Parameters options vector
        DM_status           % Variable to keep the status whether distance matrix has been calculated or not
        DM                  % Variable to hold the Distance matrix based on the selected parameters
        OutPut              % OutPut structure variable to hold the model type and projection output
        disparam            % Distance Parameter structure variable for using the previous version of Dis_Matrix function
    end
    
    methods
        % Constructor Method to intialize instance variables
        function hObject=NSC_Model_Cls()
            NL_Model_Cls();
            hObject.DM_status=false;
            hObject.DM=false;
            hObject.Options2=zeros(1,18);
            hObject.OutPut.ModelType='NSC';
            hObject.disparam.gammad = 0;
            hObject.disparam.gammaf = 0;
            hObject.disparam.disd = '';
            hObject.disparam.disf = '';
        end
        
        % Set methods to assign the values of the class member variables
        function hObject=SetModelType(hObject,MT)
            hObject.OutPut.ModelType=MT;
        end
        
        
        
        function hObject=SetOPtions2(hObject,OP)
            hObject.Options2=OP;
        end
        
        function hObject=SetDM_status(hObject,DMS)
            hObject.DM_status=DMS;
        end
        function hObject=SetDM(hObject,DM)
            hObject.DM=DM;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure        
        function hObject=GetOPtions2(hObject)
            hObject=hObject.Options2;
        end
        
        function MT=GetModelType(hObject)
            MT=hObject.OutPut.ModelType;
        end
        
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function Iterations=GetIterations(hObject)
            Iterations=hObject.Options1(14);
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        function DM_status=GetDM_status(hObject)
            DM_status=hObject.DM_Status;
        end
        
        function DM=GetDM(hObject)
            DM=hObject.DM;
        end
        
        %  Function to train the NSC Model on the given data with
        %  descriptors
        function hObject = Train_NSC_D(hObject,handles)
            % Repeat results
            reset_random();
            
            % ddata only is present
            x = handles.Data.GetValues();
            
            % -------------------------------
            % Init. and train and rbf network
            % -------------------------------
            
            input_dim = size(x, 2);             % Input dimension = no. columns
            
            % Set up the network with thin-plate spline basis functions
            hObject.OutPut.net1 = rbf(input_dim, hObject.No_RBF_Centres, hObject.Latent_Dim, 'tps', 'neuroscale');
            
            % Train network with NETLAB
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = hObject.ddvsrbftrain(hObject.OutPut.net1, [hObject.Options1; hObject.Options2], x);
            
            
            % No fingerprints => no fparam data to be saved
            
            
            % --------------------
            % Plot the error graph
            % --------------------
            
            % Forward-propagate data through network
            hObject.OutPut.y = rbffwd(hObject.OutPut.net2, x);
            hObject=hObject.SetTrainingStatus(true);
            
        end
        
        %  Function that train the NSC Model on the given data with
        %  either fingerprint data or with fingerprint and descriptors data
        function hObject = Train_NSC_DF(hObject,handles)
            % Repeat results
            reset_random();
            % Load the distance matrix
            Distfn=handles.Data.GetDistfn();
            hObject.disparam.gammad = Distfn.Getgammad();
            hObject.disparam.gammaf = Distfn.Getgammaf();
            hObject.disparam.disd = Distfn.Getdisd();
            hObject.disparam.disf = Distfn.Getdisf();
            
            if (handles.Config.GetNo_Variables > 0)                     % Is ddata present?
                % ddata is present
                x = [handles.Data.GetValues(), handles.Data.GetFingerPrint()];
                
                % Has distance matrix been computed and saved?
                if (~hObject.DM_status)
                    hObject.DM = dis_matrix(handles.Data.GetValues(), handles.Data.GetFingerPrint, hObject.disparam);                    
                    hObject.DM_status= true;
                end;
            else
                % ddata is not present (so fdata only)
                x = [handles.Data.GetFingerPrint()];
                
                % Has distance matrix been computed and saved?
                if (~hObject.DM_status)
                    empty = [];
                    hObject.DM = dis_matrix(empty, handles.Data.FingerPrint, hObject.disparam);
                    hObject.DM_status = true;
                end;
            end;
            
            
            % -------------------------------
            % Init. and train and rbf network
            % -------------------------------
            
            
            input_dim = size(x, 2);             % Input dimension = no. columns          
            
            % Set up the network with thin-plate spline basis functions
            hObject.OutPut.net1 = rbf(input_dim, hObject.No_RBF_Centres, hObject.Latent_Dim, 'tps', 'neuroscale');            
            
            % Train network with NETLAB
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = hObject.ddvsrbftrain(hObject.OutPut.net1, [hObject.Options1; hObject.Options2], x,hObject.DM);            
            
            % Forward-propagate data through network
            hObject.OutPut.y = rbffwd(hObject.OutPut.net2, x);
            hObject=hObject.SetTrainingStatus(true);
        end
        
        function [net, options, errlog] = ddvsrbftrain(handles,net, options, x, t)
            %RBFTRAIN Two stage training of RBF network.
            %
            % ----------------------------------------------------------------------------
            % JRO, 25 Feb 2009:
            % The only difference between this file and NETLAB's rbftrain seems
            % to be in the first line: this file returns the [errlog] parameter
            % but NETLAB's version does not. (To compare files: diff file1.m file2.m -b)
            % ----------------------------------------------------------------------------
            %
            %	Description
            %	NET = RBFTRAIN(NET, OPTIONS, X, T) uses a  two stage training
            %	algorithm to set the weights in the RBF model structure NET. Each row
            %	of X corresponds to one input vector and each row of T contains the
            %	corresponding target vector. The centres are determined by fitting a
            %	Gaussian mixture model with circular covariances using the EM
            %	algorithm through a call to RBFSETBF.  (The mixture model is
            %	initialised using a small number of iterations of the K-means
            %	algorithm.) If the activation functions are Gaussians, then the basis
            %	function widths are then set to the maximum inter-centre squared
            %	distance.
            %
            %	For linear outputs,  the hidden to output weights that give rise to
            %	the least squares solution can then be determined using the pseudo-
            %	inverse. For neuroscale outputs, the hidden to output weights are
            %	determined using the iterative shadow targets algorithm.  Although
            %	this two stage procedure may not give solutions with as low an error
            %	as using general  purpose non-linear optimisers, it is much faster.
            %
            %	The options vector may have two rows: if this is the case, then the
            %	second row is passed to RBFSETBF, which allows the user to specify a
            %	different number iterations for RBF and GMM training. The optional
            %	parameters to RBFTRAIN have the following interpretations.
            %
            %	OPTIONS(1) is set to 1 to display error values during EM training.
            %
            %	OPTIONS(2) is a measure of the precision required for the value of
            %	the weights W at the solution.
            %
            %	OPTIONS(3) is a measure of the precision required of the objective
            %	function at the solution.  Both this and the previous condition must
            %	be satisfied for termination.
            %
            %	OPTIONS(5) is set to 1 if the basis functions parameters should
            %	remain unchanged; default 0.
            %
            %	OPTIONS(6) is set to 1 if the output layer weights should be should
            %	set using PCA. This is only relevant for Neuroscale outputs; default
            %	0.
            %
            %	OPTIONS(14) is the maximum number of iterations for the shadow
            %	targets algorithm;  default 100.
            %
            %	See also
            %	RBF, RBFERR, RBFFWD, RBFGRAD, RBFPAK, RBFUNPAK, RBFSETBF
            %
            %  Changed for DDVS by Dharmesh Maniyar
            %  Adopted from Netlab Copyright (c) Ian T Nabney (1996-2001)
            
            % Check arguments for consistency
            switch net.outfn
                case 'linear'
                    errstring = consist(net, 'rbf', x, t);
                case 'neuroscale'
                    errstring = consist(net, 'rbf', x);
                otherwise
                    error(['Unknown output function ', net.outfn]);
            end
            if ~isempty(errstring)
                error(errstring);
            end
            
            % Allow options to have two rows: if this is the case, then the second row
            % is passed to rbfsetbf
            if size(options, 1) == 2
                setbfoptions = options(2, :);
                options = options(1, :);
            else
                setbfoptions = options;
            end
            
            if(~options(14))
                options(14) = 100;
            end
            % Do we need to test for termination?
            test = (options(2) | options(3));
            
            % Set up the basis function parameters to model the input data density
            % unless options(5) is set.
            if ~(logical(options(5)))
                net = rbfsetbf(net, setbfoptions, x);
            end
            
            % Compute the design (or activations) matrix
            [y, act] = rbffwd(net, x);
            ndata = size(x, 1);
            
            if strcmp(net.outfn, 'neuroscale') & options(6)
                % Initialise output layer weights by projecting data with PCA
                mu = mean(x);
                [pcvals, pcvecs] = pca(x, net.nout);
                xproj = (x - ones(ndata, 1)*mu)*pcvecs;
                
                % Now use projected data as targets to compute output layer weights
                temp = pinv([act ones(ndata, 1)]) * xproj;
                net.w2 = temp(1:net.nhidden, :);
                net.b2 = temp(net.nhidden+1, :);
                % Propagate again to compute revised outputs
                [y, act] = rbffwd(net, x);
            end
            
            switch net.outfn
                case 'linear'
                    % Sum of squares error function in regression model
                    % Solve for the weights and biases using pseudo-inverse from activations
                    Phi = [act ones(ndata, 1)];
                    if ~isfield(net, 'alpha')
                        % Solve for the weights and biases using left matrix divide
                        temp = pinv(Phi)*t;
                    elseif size(net.alpha == [1 1])
                        % Use normal form equation
                        hessian = Phi'*Phi + net.alpha*eye(net.nhidden+1);
                        temp = pinv(hessian)*(Phi'*t);
                    else
                        error('Only scalar alpha allowed');
                    end
                    net.w2 = temp(1:net.nhidden, :);
                    net.b2 = temp(net.nhidden+1, :);
                    
                case 'neuroscale'
                    % Use the shadow targets training algorithm
                    if nargin < 5
                        % If optional input distances not passed in, then use
                        % Euclidean distance
                        x_dist = sqrt(dist2(x, x));
                    else
                        x_dist = t;
                    end
                    Phi = [act, ones(ndata, 1)];
                    % Compute the pseudo-inverse of Phi
                    PhiDag = pinv(Phi);
                    % Compute y_dist, distances between image points
                    y_dist = sqrt(dist2(y, y));
                    
                    % Save old weights so that we can check the termination criterion
                    wold = netpak(net);
                    % Compute initial error (stress) value
                    errold = 0.5*(sum(sum((x_dist - y_dist).^2)));
                    
                    % Initial value for eta
                    eta = 0.1;
                    k_up = 1.2;
                    k_down = 0.1;
                    success = 1;  % Force initial gradient calculation
                    niters = options(14);
                    errlog = zeros(1, niters);
                    xx = 1:length(errlog);   
                    xi = xx(1);
                    yi = errlog(1);
                    h = plot(xi, yi, 'YDataSource', 'yi', 'XDataSource', 'xi'); 
                    xlim([0 niters])
                    set(h,'color','g','linewidth',2.0);
                    
                    hbar = waitbar(0,'Training in progress...');
                    
                    for j = 1:niters
                        if success
                            % Compute the negative error gradient with respect to network outputs
                            D = (x_dist - y_dist)./(y_dist+(y_dist==0));
                            temp = y';
                            neg_gradient = -2.*sum(kron(D, ones(1, net.nout)) .* ...
                                (repmat(y, 1, ndata) - repmat((temp(:))', ndata, 1)), 1);
                            neg_gradient = (reshape(neg_gradient, net.nout, ndata))';
                        end
                        % Compute the shadow targets
                        t = y + eta*neg_gradient;
                        % Solve for the weights and biases
                        temp = PhiDag * t;
                        net.w2 = temp(1:net.nhidden, :);
                        net.b2 = temp(net.nhidden+1, :);
                        
                        % Do housekeeping and test for convergence
                        ynew = rbffwd(net, x);
                        y_distnew = sqrt(dist2(ynew, ynew));
                        err = 0.5.*(sum(sum((x_dist-y_distnew).^2)));
                        if err > errold
                            success = 0;
                            % Restore previous weights
                            net = netunpak(net, wold);
                            err = errold;
                            eta = eta * k_down;
                        else
                            success = 1;
                            eta = eta * k_up;
                            errold = err;
                            y = ynew;
                            y_dist = y_distnew;
                            if test && j > 1
                                w = netpak(net);
                                if (max(abs(w - wold)) < options(2) && abs(err-errold) < options(3))
                                    if j < niters
                                        errlog(j+1:end) = []; % Remove trailing zeros
                                    end             
                                    options(8) = err;
                                    close(hbar)
                                    return;
                                end
                            end
                            wold = netpak(net);
                        end
                        if options(1)
                            fprintf(1, 'Cycle %4d: Error Func. = %11.6f\n', j, err)
                        end
                        if nargout >= 3
                            errlog(j) = err;                                           
                            xi = xx(1:j);
                            yi = errlog(1:j);
                            refreshdata(h, 'caller')
                            drawnow;  
                        end
                        waitbar(j/niters)
                    end
                    close(hbar) 
                    options(8) = errold;
                    if (options(1) >= 0)
                        disp('Warning: Maximum number of iterations has been exceeded');
                    end
                otherwise
                    error(['Unknown output function ', net.outfn]);                    
            end
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_NSC(hObject, handles)
            if (handles.Config.GetNo_Variables > 0)
                if handles.Config.GetFngPrn_ColIndx()>0
                    x = [handles.Data.GetValues(), handles.Data.GetFingerPrint()];     % Load the fingerprint and other descriptors dataset
                else
                    x = handles.Data.GetValues();                   % Load the dataset
                end
            else
                if handles.Config.GetFngPrn_ColIndx()>0
                    x = handles.Data.GetFingerPrint();               % Load the fingerprint dataset
                end
            end
            
            hObject.OutPut.y = rbffwd(hObject.OutPut.net2, x);
        end
        
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_nsc.mat'];
            TitleString=['Save As (use "', '_nsc.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
        end
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_nsc.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end            
        end        
    end
end

