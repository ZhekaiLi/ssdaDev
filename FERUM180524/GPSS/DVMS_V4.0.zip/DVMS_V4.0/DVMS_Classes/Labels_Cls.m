classdef Labels_Cls
%   Copyright (C) Shahzad Mumtaz, 2011 
    properties
        Cols
        ColsLight
        Markers
        LabelsStr
        size
    end
    methods
        function hObject=Labels_Cls()
            hObject.Cols = [0,200,200;
                255,0,0;
                0,0,255;
                0,255,0;
                255,175,0;
                255,100,255;
                0,0,0;
                155,50,0;
                0,175,255;
                0,155,50;
                0,75,255;
                155,150,100;
                110,0,155;
                0,55,100;
                55,75,110;
                255,00,150;
                0,0,100;
                100,50,100;
                250,150,0;
                0,100,250];
            hObject.Cols  = hObject.Cols/255;
            hObject.ColsLight = [184,255,255;
                255,184,184;
                184,184,255;
                184,255,184;
                255,200,128;
                255,200,255;
                128,128,128;
                155,150,50;
                125,255,255;
                155,200,155;
                125,175,255;
                200,200,150;
                210,150,255;
                150,155,250;   % Not good combination for light colors
                155,175,210;
                255,150,250;
                100,100,200;
                200,100,200;
                250,200,70;
                170,200,250];
            hObject.ColsLight  = hObject.ColsLight/255;            
            hObject.Markers = ['.', '+', 's', '^', '*','d','o','p','v','x','v','<','>','h','.','.','.','.','.','.'];
            hObject.LabelsStr = {'Label 1','Label 2','Label 3','Label 4','Label 5','Label 6','Label 7','Label 8','Label 9','Label 10','Label 11','Label 12','Label 13','Label 14','Label 15','Label 16','Label 17','Label 18','Label 19','Label 20'};
            hObject.size=0;
        end
        
        function hObject=AddLabel(hObject,Str)
            hObject.size=hObject.size+1;
            hObject.LabelsStr{hObject.size}=Str;
        end
        
        function Label=GetLabel(hObject,index)
            if index>hObject.size
                msgbox 'Accessing Label does not exist';
                Label='';
            else
                Label=hObject.LabelStr{index};
            end
        end
        
        function Color=GetCol(hObject,index)
            Color=hObject.Cols(index,:);
        end
        
        function Color=GetColLight(hObject,index)
            Color=hObject.ColsLight(index,:);            
        end
        
        function Marker=GetMarker(hObject,index)            
            Marker=hObject.Markers(index);            
        end
    end
end
