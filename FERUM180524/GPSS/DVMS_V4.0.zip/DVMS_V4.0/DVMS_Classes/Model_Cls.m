classdef Model_Cls
    %MODEL_CLS 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        TrainingStatus=false;   % Boolean variable to keep the status of the model trained or not
        SavedStatus=false;      % Boolean variable to keep the status of the trained model saveed or not
        LoadedStatus=false;     % Boolean variable to keep the status of the trained model loaded or not 
        OutPutFile              % Model OutPut file variable used to save the model
    end
    
    methods
        % Constructor Method to intialize instance variables
        function hObject=Model_Cls(hObject)
            hObject.TrainingStatus=false;
            hObject.SavedStatus=false;
            hObject.LoadedStatus=false;
            hObject.OutPutFile.Name='';
            hObject.OutPutFile.Path='';
        end
        
        % Set Methods to assign the values of the class member variables
        function hObject=SetOutPutFilePath(hObject,Path)
            hObject.OutPutFile.Path=Path;
        end
        function hObject=SetOutPutFileName(hObject,Name)
            hObject.OutPutFile.Path=Name;
        end       
        function hObject=SetTrainingStatus(hObject,Status)
            hObject.TrainingStatus=Status;
            
        end        
        function hObject=SetSavedStatus(hObject,Status)
            hObject.SavedStatus=Status;
        end        
        function hObject=SetLoadedStatus(hObject,Status)
            hObject.LoadedStatus=Status;
        end
        % Get or Is methods to extract the values of the class memebers
        % variables
        function Status=isTrained(hObject)
            Status=hObject.TrainingStatus;
        end
        
        function Status=isSaved(hObject)
            Status=hObject.SavedStatus;
        end
        
        function Status=isLoaded(hObject)
            Status=hObject.LoadedStatus;
        end
        function Path=GetOutPutFilePath(hObject)
            Path=hObject.OutPutFile.Path;
        end
        
        function Name=GetOutPutFileName(hObject)
            Name=hObject.OutPutFile.Name;
        end
        
        % Method that save the model on the specified path if the model is
        % not saved before
        function hObject=Save(hObject)
            if hObject.isSaved()
                file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
                hObject.Save_Model_Data(file,hObject.GetOutPut());
            end
        end
        
        % Method that saved the model output to the specified file and used
        % in save method written above
        function hObject=Save_Model_Data(hObject,file, OutPut)
            % Save model data in format required by ddvs & latentspacevis
            fprintf('\nSaving.....');
            save(file, 'OutPut');
            fprintf('Completed\n');
            fprintf('Model saved at: %s\n', file);
        end
        % Method that load the saved model and assign to the current object
        function hObject=Load_TrainedModel(hObject,file)
            fprintf('\nLoading.....');
            load(file);
            hObject.OutPut=OutPut;
            fprintf('Completed\n');
            fprintf('Model saved at: %s\n', file);
        end
        
    end
    
end

