classdef NL_Model_Cls < Model_Cls
    %   NL_Model_Cls 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        No_RBF_Centres      % Number of RBF centres
        Options1            % Training Algorithms parameters
        Latent_Dim          % Dimensions for Projection
    end
    
    methods
        % Constructor method to initialize instance variables
        function Obj=NL_Model_Cls()
            Model_Cls();
            Obj.No_RBF_Centres=8;
            Obj.Options1=zeros(1,18);
            Obj.Latent_Dim=2;            
        end        
        % Set methods to assign the values of the class member variables
        function Obj=SetNo_RBF_Centres(Obj,NRC)
            Obj.No_RBF_Centres=NRC;
        end       
        function Obj=SetOPtions1(Obj,OP)
            Obj.Options1=OP;
        end        
        function Obj=SetLatent_Dim(Obj,NOD)
            Obj.No_OutPut_Dim=NOD;
        end
        
        % Get methods to obtain the value of a variable        
        function Obj=GetNo_RBF_Centres(Obj)
            Obj=Obj.No_RBF_Centres;
        end        
        function Obj=GetOPtions1(Obj)
            Obj=Obj.Options1;
        end        
        function Obj=GetLatent_Dim(Obj)
            Obj=Obj.No_OutPut_Dim;
        end        
    end    
end

