classdef HGTM_Model_Cls
    %   HGTM_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    
    properties
        hgtm        % HGTM parameter structure variable (Members are intialized in the constructor)
        OutPut      % OutPut structure variable to hold the model type and projection output
        loaded      % Boolean variable for model loading status
        ModelType   % ModelType string variable
    end
    methods
        
        % Constructor method to initialize instance variables
        function hObject=HGTM_Model_Cls(hObject)
            hObject.hgtm.Parameters.Latent_Grid = [16 16];
            hObject.hgtm.Parameters.Rbf_Grid = [4 4];
            hObject.hgtm.Parameters.Rbf_Kernel_Width = 1;
            hObject.hgtm.Parameters.Prior_W_Inv_Var = 0.1000;
            hObject.hgtm.Parameters.Num_Trn_Iterations = 30;
            hObject.hgtm.Parameters.Num_Directions = 16;
            hObject.hgtm.LocalExp.compartment_type = 1; % 1 for varnoi, 2 for by responsibility
            hObject.hgtm.LocalExp.training_options.model_type = 1; % 1 for GLM
            % 2 for RBF, 3 for GLM & RBF both, 4 for KNNR
            
            hObject.hgtm.LocalExp.training_options.display_error = -1;
            hObject.hgtm.LocalExp.training_options.validation = 1;
            hObject.hgtm.LocalExp.training_options.val_per_data = 0.30; % 30%
            
            hObject.hgtm.LocalExp.modeltypes = {'GLM';'RBF';'GLM_RBF';'KNNR'};
            hObject.hgtm.LocalExp.error_func_type = 1 ;
            % 1 for accross all the experts, 2 for exptert with maximmum
            % responsibility
            
            hObject.hgtm.LocalExp.current_operation = 1; % 1 for training, 2
            % for testing
     
            hObject.hgtm.Root='';
            hObject.hgtm.Structure='';

            % Visualization type - See TrainPhiVis for more details
            % 0 - plain
            % 1 - with labels
            % 2 - depth coloring without labels
            % 4 .. 6 - white background for printing
            hObject.hgtm.Vis_Type=1;

            hObject.OutPut.y=[];
            hObject.loaded=false;
            hObject.ModelType='HGTM';
        end
        
        % Set methods to assign the values of the class member variables
        function hObject=SetModelType(hObject,MT)
            hObject.ModelType=MT;
        end
        
        % Get methods to obtain the values of instance variables
        function hgtm=Gethgtm(hObject)
            hgtm=hObject.hgtm;
        end
        function MT=GetModelType(hObject)
            MT=hObject.ModelType;
        end
        function Load=isLoaded(hObject)
            Load=hObject.loaded;
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_HGTM(hObject, handles)
            if handles.UserData.Config.GetNo_Labels > 0 % Actual labelling is there
                Labels = handles.UserData.Data.GetLabel_Values();
            else
                [row,col] = size(handles.UserData.Data.GetValues());
                Labels = ones(row,1); % All label are set to 1
            end
            pathname = handles.PathName;
            file = handles.FileName;
            fullpath = sprintf('%s%s',pathname,file);
            x = handles.UserData.Data.GetValues();                   % Load the dataset
            hgtmlocal=hObject.Gethgtm();
            h_gtm_show(x, fullpath, 0, hgtmlocal.Vis_Type, 2, Labels);
            
        end
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_hgtm.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                load(handles.file);
                hObject.loaded=true;
                
            end
        end
    end
end

