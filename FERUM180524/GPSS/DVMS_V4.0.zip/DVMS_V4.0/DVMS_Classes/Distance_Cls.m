classdef Distance_Cls
    
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    
    properties %(SetAccess=private, GetAccess=private)
        Disfn   % Distance structure variable (Members are intialized in constructor)
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function D=Distance_Cls()
            D.Disfn.gammad = 1.0;
            D.Disfn.gammaf = 1.0;
            D.Disfn.disd = 'tanimoto';
            D.Disfn.disf = 'tanimoto';
        end
        
        % Set methods to assign the values of the class member variables
        function Obj=Setgammad(Obj,d)
            Obj.Disfn.gammad=d;
        end
        function Obj=Setgammaf(Obj,f)
            Obj.Disfn.gammaf=f;
        end
        function Obj=Setdisd(Obj,d)
            Obj.Disfn.disd=d;
        end
        function Obj=Setdisf(Obj,f)
            Obj.Disfn.disf=f;
        end
        function Obj=SetDisfn(Obj,DF)
            Obj.Disfn=DF;
        end
        
        % Get methods to obtain the values of instance variables
        function d=Getgammad(Obj)
            d=Obj.Disfn.gammad;
        end
        function f=Getgammaf(Obj)
            f=Obj.Disfn.gammaf;
        end
        function d=Getdisd(Obj)
            d=Obj.Disfn.disd;
        end
        function f=Getdisf(Obj)
            f=Obj.Disfn.disf;
        end
        function bl=Getbinlim(Obj)
            bl=Obj.Disfn.binlim;
        end
        function DF=GetDisfn(Obj)
            DF=Obj.Disfn;
        end
    end
end

