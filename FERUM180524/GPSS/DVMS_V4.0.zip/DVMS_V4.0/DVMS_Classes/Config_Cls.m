classdef Config_Cls
%CONFIG_CLS: A Class required to store the configuration parameters and 
%            saving/retrieving these parameters to a configuration file  
%            supported by the previous version of DVMS and details are 
%            provided in the documentation of the software
%           
%
%   Copyright (C) Shahzad Mumtaz, NCRG, 2011
%
% This code will work with both Linux and Windows.

    
    properties % (SetAccess=private, GetAccess=private)
        Train_DS_Name       % Training DataSet Name
        No_Variables        % Number of variables in the DataSet
        No_Labels           % Number of Data Labels
        Label_Names         % Pre-defined dataset labels for the data instances
        Labels_ColIndx      % Data label field index 
        Title_RowIndx       % Index of the Title Row Default value is zero
        ID_ColIndxstat      % Instance ID column absence or presence field
        ID_ColIndx          % Data instances id field index        
        Normalization       % Data Normalization Parameter
        Target_ColIndx      % Target Column Index used for NSC
        Bin_Lim             % Bin Limits if the target column in the dataset is present
        FngPrn_ColIndx      % Data finger print field index
        Prediction
    end
    
    methods 
      
      % Constructor Methods   
      function D = Config_Cls()
         D.Train_DS_Name='DataSet Name';       
         D.No_Variables=0;
         D.No_Labels=0;      
         D.Label_Names=cell(0);    
         D.Labels_ColIndx=0;    
         D.Title_RowIndx=0; 
         D.ID_ColIndxstat=0;
         D.ID_ColIndx=0;        
         D.Normalization=0;        
         D.Target_ColIndx=0;
         D.Bin_Lim=-99 * ones(1, 5);
         D.FngPrn_ColIndx=0;
         D.Prediction=0;
       end
                 
       % Set Methods to set the data to the fields of the class

       function D=SetTrain_DS_Name(D,DS)
         D.Train_DS_Name=DS;
       end
       
       function D=SetNo_Variables(D,NV)
         D.No_Variables=NV;
       end
       
       function D=SetNo_Labels(D,NL)
         D.No_Labels=NL;
       end
        
       function D=SetLabel_Names(D,LN)
         D.Label_Names=LN;
       end
       
       function D=SetLabels_ColIndx(D,DLI)
         D.Labels_ColIndx=DLI;
       end
       
       function D=SetTitle_RowIndx(D,DTRI)
         D.Title_RowIndx=DTRI;
       end
              
       function D=SetID_ColIndxstat(D,DIIS)
        D.ID_ColIndxstat=DIIS;
       end
       
       function D=SetID_ColIndx(D,DII)
        D.ID_ColIndx=DII;
       end
        
       function D=SetNormalization(D,DN)
        D.Normalization=DN;
       end
       
       function D=SetTarget_ColIndx(D,TI)
        D.Target_ColIndx=TI;
       end
       
       function D=SetBin_Lim(D,bl)
            D.Bin_Lim=bl;
       end
        
       function D=SetFngPrn_ColIndx(D,DFNI)
        D.FngPrn_ColIndx=DFNI;
       end
       
       
       function D=SetPrediction(D,P)
        D.Prediction=P;
       end
% Get Methods to read the fields of the class
       
       function D=GetTrain_DS_Name(D)
        D=D.Train_DS_Name;
       end
        
       function D=GetNo_Variables(D)
        D=D.No_Variables;
       end
       
       function D=GetNo_Labels(D)
        D=D.No_Labels;
       end
       
       function D=GetLabel_Names(D)
        D=D.Label_Names;
       end
       
       function D=GetLabels_ColIndx(D)
        D=D.Labels_ColIndx;
       end
       
       function D=GetTitle_RowIndx(D)
         D=D.Title_RowIndx;
       end
       
       function D=GetID_ColIndxstat(D)
        D=D.ID_ColIndxstat;
       end
       
       function D=GetID_ColIndx(D)
        D=D.ID_ColIndx;
       end
       
       function D=GetNormalization(D)
        D=D.Normalization;
       end
       
       function D=GetTarget_ColIndx(D)
        D=D.Target_ColIndx;
       end
       
       function BL=GetBin_Lim(D)
            BL=D.Bin_Lim;
       end
       
       function D=GetFngPrn_ColIndx(D)
        D=D.FngPrn_ColIndx;
       end
       
       
       function P=GetPrediction(D)
        P=D.Prediction;
       end
       
       % Function to read the Configuration File
       function D=ReadConfigurationFile(D,filepath)
       
        %READ_CONFIG    Read a DVMS configuration file
        % John R. Owen, NCRG, Aston University, 14 Jul 2009
        % conffile      Holds path to config. file
        %
        %  A code is ammended by 
        %  Shahzad Mumtaz, NCRG, Aston University, February 2011
        %
        %
        %
        %
        fprintf('\nReading config. file: %s\n', filepath);

        % Count no. of lines in conffile
        fid = fopen(filepath);
        i = 0;
        while (true);
            h1 = fgetl(fid);
            if (~ischar(h1))
                break;
            end;
            i = i + 1;
        end;
        fclose(fid);
        
        % Set up the array to hold lines in conffile
        lines = cell(i, 1);


        % Read the file and store lines
        fid = fopen(filepath);
        for j = 1:i;
            lines{j} = strtrim(fgetl(fid));
        end;
        fclose(fid);
       
        % Check for correct file format
        h1 = find(strcmp(lines, '$CONFIG_START') == 1);
        if (all(h1 == 0))
            fprintf('\nError - "$CONFIG_START" not found in configuration file\n');
            fprintf('Check format of config. (.cfg) file\n');
            return;
        end;
        
        
        % Remove blank lines from lines
        h1 = strcmp(lines, '');        % Vector of blank lines
        h2 = sum(h1 == 0);             % Count no. of non-blank lines
        h1 = cell(h2, 1);              % Hold non-blank lines
        j = 0;
        for i = 1:length(lines);
            if (~strcmp(lines{i}, ''))
                j = j + 1;
                h1{j} = lines{i};
            end;
        end;
        lines = h1;
        
        h1=find(strcmp(lines,'$DATASET_NAME')==1);
        if (~isempty(h1))
         D.Train_DS_Name=lines{h1+1};       
        end;
           
        h1=find(strcmp(lines,'$NO_VARIABLES')==1);
        if (~isempty(h1))
         D.No_Variables= str2num(lines{h1+1});       
        end;
         
        h1=find(strcmp(lines,'$NO_LABELS')==1);
        if (~isempty(h1))
         D.No_Labels= str2num(lines{h1+1});       
        end;
         
        % The following options are strings, or require multiple line readings,
        % so must be handled as special cases.
        %

        % Read in labels (if no. labels > 0)
        if (D.No_Labels > 0)
            h1 = find(strcmp(lines, '$LABEL_NAMES') == 1);
            if (~isempty(h1))
                for i = 1:(D.No_Labels)
                    h2 = lines{h1 + i};
                    D.Label_Names(i) = cellstr(h2);
                end;
            end;
        end;
         
        h1=find(strcmp(lines,'$LABELS_COLUMN_INDEX')==1);
        if (~isempty(h1))
         D.Labels_ColIndx= str2num(lines{h1+1});       
        end;
        
        h1=find(strcmp(lines,'$TITLE_ROW_INDEX')==1);
        if (~isempty(h1))
         D.Title_RowIndx=str2num(lines{h1+1});       
        end;
        
        h1=find(strcmp(lines,'$ID_COLUMN_INDEXSTATUS')==1);
        if (~isempty(h1))
          D.ID_ColIndxstat=str2num(lines{h1+1});
          if (D.ID_ColIndxstat==1)
            h1=find(strcmp(lines,'$ID_COLUMN_INDEX')==1);
            if (~isempty(h1))
                D.ID_ColIndx= str2num(lines{h1+1});       
            end;
          end;
        end;
        
        h1=find(strcmp(lines,'$NORMALIZATION')==1);
        if (~isempty(h1))
         D.Normalization= str2num(lines{h1+1});       
        end;
        
        h1=find(strcmp(lines,'$TARGET_COLUMN_INDEX')==1);
        if (~isempty(h1))
         D.Target_ColIndx= str2num(lines{h1+1});       
        end;
        
        % Read in bin-limits; 5 limits on successive lines
        if D.Target_ColIndx>0
            h1 = find(strcmp(lines, '$BIN_LIMITS') == 1);
            if (~isempty(h1))
                h2 = cell(5, 1);
                h2{1} = lines{h1 + 1};
                h2{2} = lines{h1 + 2};
                h2{3} = lines{h1 + 3};
                h2{4} = lines{h1 + 4};
                h2{5} = lines{h1 + 5};
                D.Bin_Lim = str2double(h2);
            end;
        end
        h1=find(strcmp(lines,'$FINGERPRINT_COLUMN_INDEX')==1);
        if (~isempty(h1))
         D.FngPrn_ColIndx= str2num(lines{h1+1});       
        end;
            
        h1=find(strcmp(lines,'$Prediction')==1);
        if (~isempty(h1))
         D.Prediction= str2num(lines{h1+1});       
        end;
        
       end
       
       % Writing configuration to the file 
       
        function D=WriteconfigurationFile(D,filepath)
       
        %WriteConfigurationFile    Writes a DVMS configuration file
        % Shahzad Mumtaz, NCRG, Aston University, 08 Feb 2011
        % conffile      Holds path to config. file
        %
        %
        %
        %
        fprintf('\nWriting config. file: %s\n', filepath);

        % Count no. of lines in conffile
        fid = fopen(filepath,'w');
        
        
        fprintf(fid,'%s\n','$CONFIG_START');      
        
        fprintf(fid,'%s\n','$DATASET_NAME');   
        fprintf(fid,'%s\n',D.Train_DS_Name);
        
        fprintf(fid,'%s\n','$NO_VARIABLES');   
        fprintf(fid,'%d\n',D.No_Variables);    
        
        fprintf(fid,'%s\n','$NO_LABELS');   
        fprintf(fid,'%d\n',D.No_Labels);      
        
        fprintf(fid,'%s\n','$LABEL_NAMES');          

        if (D.No_Labels > 0)
           for i = 1:1:D.No_Labels
               s=D.Label_Names{i}; 
               fprintf(fid,'%s\n',s);
           end;
        end;
       
        fprintf(fid,'%s\n','$LABELS_COLUMN_INDEX');   
        fprintf(fid,'%d\n',D.Labels_ColIndx);      
                       
        fprintf(fid,'%s\n','$TITLE_ROW_INDEX');   
        fprintf(fid,'%d\n',D.Title_RowIndx);      
        
        fprintf(fid,'%s\n','$ID_COLUMN_INDEXSTATUS');   
        fprintf(fid,'%d\n',D.ID_ColIndxstat);  
        
        fprintf(fid,'%s\n','$ID_COLUMN_INDEX');   
        fprintf(fid,'%d\n',D.ID_ColIndx);      
        
        fprintf(fid,'%s\n','$NORMALIZATION');   
        fprintf(fid,'%d\n',D.Normalization);  
        
        fprintf(fid,'%s\n','$TARGET_COLUMN_INDEX');   
        fprintf(fid,'%d\n',D.Target_ColIndx);  
        
        if ~(D.Target_ColIndx==0)
            fprintf(fid,'%s\n','$BIN_LIMITS');   
            if (D.Target_ColIndx>0)
                for i = 1:1:5
                    s=D.Bin_Lim(i); 
                    fprintf(fid,'%d\n',s);
                end;
            end;
        end;
        
        fprintf(fid,'%s\n','$FINGERPRINT_COLUMN_INDEX');   
        fprintf(fid,'%d\n',D.FngPrn_ColIndx);      
      
        fprintf(fid,'%s\n','CONFIG_END');
        fclose(fid);
       end
       
        
    end
    
end
