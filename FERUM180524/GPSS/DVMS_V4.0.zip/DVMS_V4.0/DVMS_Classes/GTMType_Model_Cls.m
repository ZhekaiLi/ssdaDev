classdef GTMType_Model_Cls < NL_Model_Cls
    %   GTMType_Model_Cls 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        No_Latent_Rows      % Number of Latent rows variable used for all type of GTM type models
        PWIV                % Prior Weight Inverse Variance 
    end
    
    methods
        % Constructor method to initialize instance variables
        function Obj=GTMType_Model_Cls()
            NL_Model_Cls();
            Obj.No_Latent_Rows=12;
            Obj.PWIV=0.1;            
        end
        
        % Set methods to assign the values of the class member variables
        function Obj=SetNo_Latent_Rows(Obj,NRC)
            Obj.No_Latent_Rows=NRC;
        end        
        function Obj=SetPWIV(Obj,PW)
            Obj.PWIV=PW;
        end
        
        % Get methods to obtain the value of a variable        
        function Obj=GetNo_Latent_Rows(Obj)
            Obj=Obj.No_Latent_Rows;
        end        
        function Obj=GetPWIV(Obj)
            Obj=Obj.PWIV;
        end        
    end    
end

