classdef LTM_Model_Cls < GTM_Model_Cls
    %   GTMFS_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        Noise_Mod = 'b';    % Noise model for LTM
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function Obj=LTM_Model_Cls()            
            Obj.Noise_Mod='b'; % Noise model can be: 'b' = Bernoulli, 'g' = Gaussian, 'm' = Multinomial (i.e. observation is histogram over its components), 'p' = Poisson
            % Only the Bernoulli is appropriate for fingerprint-(0, 1) data            
        end
                
        % Set methods to assign the values of the class member variables        
        function Obj=SetNoise_Mod(Obj,NM)
            Obj.Noise_Mod=NM;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure
        function Obj=GetNoise_Mod(Obj)
            Obj=Obj.Noise_Mod;
        end
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
                
        %  Function to train LTM Model for the given dataset with
        %  fingerprints data only
        function hObject = Train_LTM(hObject, handles)
            %TRAIN_LTM  Train LTM model
            %
            % John R. Owen, NCRG, Aston University, 29 Jul 2009
            %
            
            
            fprintf('\nTraining LTM\n');
            
            % Repeat results
            reset_random();
            
            % Dataset parameters
            x = handles.Data.GetFingerPrint();                    % Load main dataset (NB: fp, not val)
            if isempty(x)
                x=handles.Data.GetValues();
            end
            [xr, xc] = size(x);             % No. rows, no. columns in dataset
            
            
            % -----------------------
            % Init. gtm (ltm) network
            % -----------------------
            
            
            
            latgrid = [hObject.No_Latent_Rows, hObject.No_Latent_Rows];         % Latent-space grid layout
            rbfgrid = [hObject.No_RBF_Centres, hObject.No_RBF_Centres];          % RBF-centre grid layout
            latp = prod(latgrid);                                        % No. latent-space points
            rbfc = prod(rbfgrid);                                        % No. of RBF centres
            
            
            % Set up gtm network
            hObject.OutPut.net1 = gtm_a(hObject.Latent_Dim, latp, xc, rbfc, 'gaussian', hObject.PWIV, hObject.Noise_Mod);
            
            % Init. gtm network           
            hObject.OutPut.net1 = gtminit_a(hObject.OutPut.net1, hObject.Options1, x, 'regular', latgrid, rbfgrid);
            
            
            % -----------------
            % Train gtm network
            % -----------------            
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = gtmem_a(hObject.OutPut.net1, x, hObject.Options2);
            
            
            % Load return parameters
            % net2 is already set
            hObject.OutPut.errlog = (hObject.OutPut.errlog / xr);         % Put error log on correct scale for plotting
            hObject.OutPut.y = gtmlmean_a(hObject.OutPut.net2, x);        % Get points ready to plot
            hObject=hObject.SetTrainingStatus(true);
            
        end
        
       % Function used to test the given dataset with trained model 
        function hObject = Test_LTM(hObject, handles)
            x =  handles.Data.GetFingerPrint();                   % Load the dataset
            hObject.OutPut.y = gtmlmean_a(hObject.OutPut.net2, x);
        end
        
       % Method to save the model prompting the user for the name of
        % the model with the suggested format 
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_ltm.mat'];
            TitleString=['Save As (use "', '_ltm.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
            
        end
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_ltm.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
        end
    end
end

