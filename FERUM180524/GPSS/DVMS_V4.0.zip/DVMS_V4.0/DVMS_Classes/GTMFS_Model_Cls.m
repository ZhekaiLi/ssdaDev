classdef GTMFS_Model_Cls < GTMType_Model_Cls
    %   GTMFS_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    
    properties
        Options2    % Options for GTM-FS parameters
        OutPut      % OutPut structure variable to hold the model type and projection output
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function Obj=GTMFS_Model_Cls()
            GTMType_Model_Cls();
            Obj.OutPut.ModelType='GTMFS';           
            Obj.Options2.maxiter = 20;         % Max. no. iterations
            Obj.Options2.verb = 1.0;
            Obj.Options2.tol = 1.0e-7;
            Obj.Options2.ftwt_sup = 1.0;
            Obj.Options2.graph_interval = -1;
        end
        
        % Set methods to assign the values of the class member variables
        function Obj=SetOPtions2_Maxiter(Obj,OP)
            Obj.Options2.maxiter=OP;
        end        
        function Obj=SetOPtions2_Verb(Obj,OP)
            Obj.Options2.verb=OP;
        end        
        function Obj=SetOptions2_Tol(Obj,OP)
            Obj.Options2.tol=OP;
        end        
        function Obj=SetOptions2.ftwt_sup(Obj,OP)
            Obj.Options2.ftwt_sup=OP;
        end
        function Obj=SetOption2.graph_interval(Obj,OP)
            Obj.Options2.graph_interval=OP;
        end
        function Obj=SetModelType(Obj,MT)
            Obj.OutPut.ModelType=MT;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure
        function Obj=GetOPtions2_Maxiter(Obj)
            Obj=Obj.Options2.maxiter;
        end        
        function Obj=GetOPtions2_Verb(Obj)
            Obj=Obj.Options2.verb;
        end        
        function Obj=GetOptions2_Tol(Obj)
            Obj=Obj.Options2.tol;
        end        
        function Obj=GetOptions2_ftwt_sup(Obj)
            Obj=Obj.Options2.ftwt_sup;
        end        
        function Obj=GetOption2_graph_interval(Obj)
            Obj=Obj.Options2.graph_interval;
        end        
        function MT=GetModelType(Obj)
            MT=Obj.OutPut.ModelType;
        end        
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        function Saliencies=GetSal(hObject)
            Saliencies= hObject.OutPut.sal;
        end        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        %  Function to train GTM Model for the given dataset
        function hObject = Train_GTMFS(hObject, handles)
            %TRAIN_GTMFS  Train GTM-FS model
            %
            % John R. Owen, NCRG, Aston University, 29 Jul 2009
            %
            % Output:
            % net2          Trained network
            % y             Points to be plotted
            % errlog        Error log
            % sal           Feature saliencies
            %
            
            fprintf('\nTraining GTM-FS model\n');
                                   
            % Dataset parameters
            x = handles.Data.GetValues();   % Load the dataset
            [~, xc] = size(x);             % No. rows, no. columns in dataset
            
            
            % --------------------
            % Init. gtm-fs network
            % --------------------
            
            
            latgrid = [hObject.No_Latent_Rows, hObject.No_Latent_Rows];         % Latent-space grid layout
            rbfgrid = [hObject.No_RBF_Centres, hObject.No_RBF_Centres];          % RBF-centre grid layout
            latp = prod(latgrid);                                        % No. latent-space points
            rbfc = prod(rbfgrid);                                        % No. of RBF centres
            
            
            % Set up gtm-fs network
            hObject.OutPut.net1 = gtmfs(hObject.Latent_Dim, latp, xc, rbfc, 'gaussian', hObject.PWIV);
            
            % Init. gtm-fs network
            
            
            hObject.OutPut.net1 = gtmfsinit(hObject.OutPut.net1, hObject.Options1, x, 'regular', latgrid, rbfgrid);
            
            
            % --------------------
            % Train gtm-fs network
            % --------------------
            
            % For documention on the options list see: gtmfsem.m
            
            
            % Call EM algorithm for feature saliency with GTM
            hObject.OutPut.gtmfsmod = gtmfsem(hObject.OutPut.net1, (x'), hObject.Options2);
            
            
            % ----------------------
            % Load return parameters
            % ----------------------
            hObject.OutPut.net2 = hObject.OutPut.gtmfsmod.net;                % Load network
            hObject.OutPut.y = gtmlmean(hObject.OutPut.net2, x);              % Load coords for plotting
            hObject.OutPut.errlog = hObject.OutPut.gtmfsmod.errlog;           % Load error log
            hObject.OutPut.sal = hObject.OutPut.gtmfsmod.ftwt;                % Load feature saliencies
            hObject=hObject.SetTrainingStatus(true);
            
            
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_GTMFS(hObject, handles)
            x = handles.Data.GetValues();                   % Load the dataset
            hObject.OutPut.y = gtmlmean(hObject.OutPut.net2, x);
        end
       
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_gtmfs.mat'];
            TitleString=['Save As (use "', '_gtmfs.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
        end
        
        % Method to load saved trained model
        function [hObject handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_gtmfs.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) | isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
        end
    end
    
end

