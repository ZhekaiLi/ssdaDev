classdef Data_Cls
    %Data_Cls:   A Class required to store the data parameters and
    %            retrieving these parameters from a data file(in .csv format)
    %            supported by the previous version of DVMS and details are
    %            provided in the documentation of the software.
    %
    %
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    % This code will work with both Linux and Windows.
    %
    %
    properties %(SetAccess=private, GetAccess=private)
        Title_Row            % A data column title row
        Col_TitRow           % A column type row which indicates the type of the coulmn in the DVMS to read the data
        Header_Str           % A data columns title row that contains data column titles with the number
        Id_Values            % Data ID values column vector to contain the instance IDs
        Label_Values         % Data Instance Label Values
        No_DataRows          % Number of Data Rows (Data Instances)
        No_DataColumns       % Number of data column Values (Data Dimensions)
        Values               % Data Values in the matrix format
        Range_Values         % Minimum and Maximum Range Values for the data values
        Target_Values
        Pre_Process          % Varibale that contains the pre-process information as a structure of mean, variance and projections
        Distfn               % For FingerPrint Parameters
        FingerPrint          % Variable to hold finger prints
    end
    
    methods
        % Constructor Methods
        function D=Data_Cls()
            D.Title_Row='';
            D.Col_TitRow='';
            D.Header_Str='';
            D.Id_Values='';
            D.Label_Values='';
            D.No_DataRows=0;
            D.No_DataColumns=0;
            D.Values=0;
            D.Range_Values=[];
            D.Distfn=Distance_Cls();
            D.FingerPrint=[];
        end
        
        % Set Methods to set the data to the fields of the class
        function D=SetTitle_Row(D,TR)
            D.Title_Row=TR;
        end
        
        function D=SetCol_TitRow(D,CTR)
            D.Col_TitRow='';
        end
        
        function D=SetHeader_Str(D,HS)
            D.Header_Str=HS;
        end
        
        function D=SetId_Values(D,IV)
            D.Id_Values=IV;
        end
        
        function D=SetLabel_Values(D,LV)
            D.Label_Values=LV;
        end
        
        
        function D=SetNo_DataRows(D,NR)
            D.No_DataRows=NR;
        end
        function D=SetNo_DataColumns(D,NC)
            D.No_DataColumns=NC;
        end
        function D=SetValues(D,V)
            D.Values=V;
        end
        
        function hObject=SetRange_Values(hObject,Range)
            hObject.Range_Values=Range;
        end
        
        function hObject=SetTarget_Values(hObject,Target)
            hObject.Target_Values=Target;
        end
        
        function hObject=SetDistfn(hObject,DF)
            hObject.Distfn=DF;
        end
        
        function hObject=SetFingerPrint(hObject,F)
            hObject.FingerPrint=F;
        end
        % Get Methods to read the fields of the class
        function D=GetTitle_Row(D)
            D=D.Title_Row;
        end
        
        function D=GetCol_TitRow(D)
            D=D.Col_TitRow;
        end
        
        function D=GetHeader_Str(D)
            D=D.Header_Str();
        end
        
        function D=GetId_Values(D)
            D=D.Id_Values;
        end
        
        function D=GetLabel_Values(D)
            D=D.Label_Values;
        end
        
        function D=GetNo_DataRows(D)
            D=D.No_DataRows;
        end
        
        function D=GetNo_DataColumns(D)
            D=D.No_DataColumns;
        end
        
        function D=GetValues(D)
            D=D.Values;
        end
        function Range=GetRange_Values(hObject)
            Range=hObject.Range_Values;
        end
        
        function Target=GetTarget_Values(hObject)
            Target=hObject.Target_Values;
        end
        function Pre_Process=GetPre_Process(hObject)
            Pre_Process=hObject.Pre_Process;
        end
        
        function DF=GetDistfn(hObject)
            DF=hObject.Distfn;
        end
        
        function F=GetFingerPrint(hObject)
            F=hObject.FingerPrint;
        end
        
        function [Conf D]=ReadDataFile(D,Conf,filepath,Pb)
            
            %READ_DATA  Read a DVMS data file
            %
            % John R. Owen, NCRG, Aston University, 14 Jul 2009
            %
            % datafile  Holds path to the data file
            % conf      Holds the conf structure (read by read_config())
            %
            
            
            fprintf('\nReading data file: %s\n', filepath);
            
            
            
            
            % --------------------------------------------------------
            % Load entire data file into a cell array of strings (cas)
            % --------------------------------------------------------
            
            % Find no. columns in dataset
            fid = fopen(filepath, 'r');
            h1 = fgetl(fid);                % Get first line
            fclose(fid);                    % File no longer required
            nc = sum(h1 == ',') + 1;        % Load no. columns
            
            % Find no. of non-blank lines in dataset
            nr = 0;
            fid = fopen(filepath, 'r');
            while (true);
                h1 = fgetl(fid);
                if (~ischar(h1))
                    break;
                end;
                h1 = strtrim(h1);
                if (~isequal(h1, ''))
                    nr = nr + 1;
                end;
            end;
            fclose(fid);
            
            % Set up the main dataset array
            ds = cell(nr, nc);
            
            % Read whole dataset into ds
            % Load data in and store all values in ds (a cas)
            fid = fopen(filepath, 'r');
            
            frmt = repmat('%s ', 1, nc);
            i = 0;
            while (true);
                h1 = fgetl(fid);
                if (~ischar(h1))
                    break;
                end;
                h1 = strtrim(h1);
                if (~isequal(h1, ''))
                    % Split line of text on commas
                    h1 = textscan(h1, frmt, 'delimiter', ',');
                    i = i + 1;
                    for j = 1:nc;
                        ds{i, j} = char(strtrim(h1{j}));
                    end;
                end;
                
                
            end;
            fclose(fid);
            
            
            % Extract title row and column-type row
            if (Conf.GetTitle_RowIndx())
                D.Title_Row = ds(1, :);            % Load title row
                ds(1, :) = [];              % Delete entire row
                nr = nr - 1;                % Update no. rows
            end;
            % Load column-type row
            % Note index 1 here, not 2, as row 1 deleted for trow above
            D.Col_TitRow= lower(ds(1, :));         % Store row as all lowercase
            ds(1, :) = [];                  % Delete entire row
            nr = nr - 1;                   % Update no. rows
            
            % ---------------------------
            % Extract column-type indices
            % ---------------------------
            
            % Count no. of v and x columns
            nvcol = 0;
            nxcol = 0;
            for i = 1:nc;
                if (strcmp(D.Col_TitRow{i}, 'v'))
                    nvcol = nvcol + 1;
                elseif (strcmp(D.Col_TitRow{i}, 'x'))
                    nxcol = nxcol + 1;
                end;
            end;
            
            % Arrays to hold v and x columns
            vcol = zeros(1, nvcol);             % Variable column numbers
            xcol = zeros(1, nxcol);             % External column numbers
            lcol=0;
            fcol=0;
            tcol=0;
            % Indices for vcol and xcol
            vi = 1;
            xi = 1;
            
            % Extract column-types
            for i = 1:nc;
                h1 = D.Col_TitRow{i};
                if (strcmp(h1, 'id'))
                    icol = i;
                elseif (strcmp(h1, 'v'))
                    vcol(vi) = i;
                    vi = vi + 1;
                elseif (strcmp(h1, 'x'))
                    xcol(xi) = i;
                    xi = xi + 1;
                elseif (strcmp(h1, 'label'))
                    lcol = i;
                elseif (strcmp(h1, 'target'))
                    tcol = i;
                elseif (strcmp(h1, 'fingerprint'))
                    fcol = i;
                else
                    fprintf('ERROR: column-type identifier not recognised. Identifier: %s', h1);
                end;
                if nargin==4
                    Pb = progressbar( Pb,1/nc );
                    if ~gui_active
                        break;
                    end
                end
            end;
            
            if (icol == 0)
                fprintf('ERROR: ID column not found (dataset must contain an ID column)');
            end;
            
            
            % -----------------------------------------
            % title row present => load data.header_str
            % -----------------------------------------
            
            if ((Conf.GetTitle_RowIndx()) && (nvcol))
                % Load the variable names
                h1 = D.Title_Row(vcol);
                
                % Add in square brackets as required by dvms
                for i = 1:length(h1);
                    h1{i} = h1{i};
                end;
                
                % Finally save the cas
                D.Header_Str = h1;
            end;
            
            
            % -----------------------
            % Extract columns from ds
            % -----------------------
            
            % Extract the ID column. ID must always be present
            % ID column is a cell array of strings (cas)
            
            D.Id_Values = ds(:, icol);
            h1 = num2str(zeros(nr, 1));
            h1 = cellstr(h1);
            ds(:, icol) = h1;                   % Pad with zeros for the cellfun call
            
            % Extract the fingerprints if present
            % fprint column is a cas
            
            %%%%%%%%%%%%%%Following block is made comment by shahzad mumtaz on 10 02 20111 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if (fcol)
                f1 = ds(:, fcol);               % Hold the fdata strings
                h1 = num2str(zeros(nr, 1));
                h1 = cellstr(h1);
                ds(:, fcol) = h1;               % Pad with zeros for the cellfun call
            end;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Nice function call here: convert ds (cas) to numeric
            % ds must not, of course, contain any non-numeric data
            ds = cellfun(@str2double, ds);
            
            %%%%%%%%%%%%%% Following code is also commented by shahzad mumtaz on 10 02 1011%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Load prediction column with zeros to maintain compatibility with dvms 1.8
            % The line below is probably unnecessary
            % data.target = zeros(nr, 1);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            
            % Load the variable columns if present
            if (nvcol)
                D.Values = ds(:, vcol);
            else
                % Indicate no descriptor data present
                % Need data.val = 0 to maintain compatibility with dvms 1.8
                D.Values = 0;
            end;
            
            % Load the label column if present
            if (lcol)
                D.Label_Values = ds(:, lcol);
            else
                % Bug in Dharmesh's code
                % When saving all points, Dharmesh assumed labels are always present
                % So insert pseudo-labels here
                h1 = size(ds, 1);
                D.Label_Values = -9999 * ones(h1, 1);
            end;
            
            % Load the NSC-target column if present
            
            if (tcol)
                D.Target_Values = ds(:, tcol);
            end;
            
            
            %-------------------------------------------
            %Convert the fprint strings to numeric array
            %-------------------------------------------
            
            if (fcol)                                   % Fingerprints present?
                nbits = 166;                            % No. bits in MDL166 fprint
                fp = zeros(nr, nbits);                  % Numeric fprint array
                for i = 1:nr;
                    h1 = f1{i};                         % Load the fprint string
                    h1 = h1(3:end);                     % Chop off "FP"
                    for j = 1:nbits;
                        h2 = h1(j);                     % Load a bit
                        fp(i, j) = str2double(h2);      % Convert to numeric
                    end;
                end;
                D.FingerPrint = fp;                           % Save the numeric array
            end;
            
            
            % -----------------------------------------------
            % Dataset parameters, normalisation and whitening
            % -----------------------------------------------
            
            % Dataset size
            [D.No_DataRows, D.No_DataColumns] = size(D.Values);
            D.Range_Values = [floor(min(min(D.Values))), ceil(max(max(D.Values)))];            
            % Data normalisation required?
            % norm = 1 => normalisation (mean = 0, var = 1)
            % norm = 2 => data whitening required
            if (Conf.Normalization == 1)
                
                % Normalise fprint data?
                if (fcol)
                    [D.Pre_Process, D.FingerPrint] = normal(D.FingerPrint);
                end;
                
                % Normalise data?
                if (nvcol)
                    % Note: preproc is overwritten in this call
                    [D.Pre_Process, D.Values] = normal(D.Values);
                end;
            end;
            
            
            % Data whitening required?
            if (Conf.Normalization == 2)
                
                % Whiten fprint data?
                if (fcol)
                    [D.Pre_Process, D.FingerPrint] = whitening(D.FingerPrint);
                end;
                
                % Whiten ddata?
                if (nvcol)
                    % Note: preproc is overwritten in this call
                    [D.Pre_Process, D.Values] = whitening(D.Values);
                end;
                
                % Whiten target data?
                % data.target not used in dvms. Relic from dvms 1.8
                if (Config.GetPrediction())
                    [D.target_preproc, D.target] = whitening(data.target);
                end;              
            end;
            
            
            % ----------------------------------
            % Dump data file structure to screen
            % ----------------------------------
            fprintf('\nDATA FILE PARAMETERS:\n\n');
            disp(D);
            progressbar( Pb,-1 );
            
            
            % ----------------------------------------
            % Load conf variables to pass back to dvms
            % ----------------------------------------
            Conf=Conf.SetNo_Variables(nvcol);          
            Conf=Conf.SetLabels_ColIndx(lcol);
            
            Conf=Conf.SetFngPrn_ColIndx(fcol);
            Conf=Conf.SetTarget_ColIndx(tcol);           
        end      
    end 
end

