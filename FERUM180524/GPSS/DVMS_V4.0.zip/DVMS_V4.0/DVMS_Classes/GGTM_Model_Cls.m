classdef GGTM_Model_Cls < GGTMGen_Model_Cls
    %   GGTM_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2014    
    
    properties
        OutPut  % OutPut structure variable to hold the model type and projection output
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function handles=GGTM_Model_Cls()
            GGTMGen_Model_Cls();
            handles.OutPut.ModelType='GGTM';
        end
        
        % Set methods to assign the values of the class member variables
        function hObject=SetModelType(hObject,MT)
            hObject.OutPut.ModelType=MT;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure
        function MT=GetModelType(hObject)
            MT=hObject.OutPut.ModelType;
        end
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        %  Function to train GGTM Model for the given dataset
        function hObject = Train_GGTM(hObject, handles)
            %TRAIN_GGTM  Train GGTM model
            %
            % John R. Owen, NCRG, Aston University, 29 Jul 2009
            %
            %
            % Output:
            % net2      trained network structure
            % y         array of points to be plotted
            % errlog    log (array) of training errors
            % Modified  Shahzad Mumtaz to make it compatible with the object oriented version of DVMS
            
            fprintf('\nTraining GGTM model\n');          
                     
            % -----------------
            % Init. gtm network
            % -----------------
            
            latgrid = [hObject.No_Latent_Rows, hObject.No_Latent_Rows];         % Latent-space grid layout
            rbfgrid = [hObject.No_RBF_Centres, hObject.No_RBF_Centres];         % RBF-centre grid layout
            latp = prod(latgrid);           % No. latent-space points
            samp_type = 'regular';
            
            % Data array
            data_array = handles.data_array;

            ndata = size(data_array,2);
            dim_data_array = zeros(1,ndata);
            for i=1:ndata
                dim_data_array(i) = data_array{i}.nvar;
            end

            % Mapping function
            map = handles.map;

            % Mixture models array
            mix_array = handles.mix_array;            
            
            % Set up gtm network          
            hObject.OutPut.net1 = ggtm(hObject.Latent_Dim, latp, dim_data_array, map, mix_array);          
            vsrmi = handles.vsrmi;
            if isempty(vsrmi)
                hObject.OutPut.net1 = ggtminit(hObject.OutPut.net1, hObject.Options1, data_array, samp_type, latgrid,rbfgrid);
            else
                hObject.OutPut.net1 = ggtminit(hObject.OutPut.net1, hObject.Options1, data_array, samp_type, latgrid,rbfgrid,vsrmi);
            end
           
            
            % -----------------
            % Train gtm network
            % -----------------
            
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = ggtmem(hObject.OutPut.net1, data_array, hObject.Options2);         
            
            % Get coords for plotting
            hObject.OutPut.y = ggtmlmean(hObject.OutPut.net2, data_array);           
            hObject=hObject.SetTrainingStatus(true);
            
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_GGTM(hObject, handles)
            h1=findobj('tag', 'TrainNewModelGUI_Main');
            data_array = getappdata(h1,'data_array');
            mix_array = getappdata(h1,'mix_array');
            
            nb_obs_space = length(hObject.OutPut.net2.obs_array);
            if nb_obs_space ~= length(data_array)
                err_str = ['Error: there should be ' num2str(nb_obs_space) ' observation space(s)'];
                errordlg(err_str)
                error(err_str)
            end
            for i=1:nb_obs_space
               nb_var = hObject.OutPut.net2.obs_array{i}.nin;
               if nb_var ~= data_array{i}.nvar
                   err_str = ['Error: there should be ' num2str(nb_var) ' variables in the observation space #' num2str(i)];
                   errordlg(err_str)
                   error(err_str)
               end
               mix_type = hObject.OutPut.net2.obs_array{i}.mix.type;
               if ~strcmp(mix_type,mix_array{i}.type)
                   err_str = ['Error: the type of mixture in the observation space #' num2str(i) ' should be ' mix_type];
                   errordlg(err_str)
                   error(err_str)                   
               end
            end
            
            hObject.OutPut.y = ggtmlmean(hObject.OutPut.net2, data_array);
        end
        
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_ggtm.mat'];
            TitleString=['Save As (use "', '_ggtm.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
            
        end
        
        % Method to load saved trained model
        function [hObject, handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_ggtm.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) || isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
        end
        
    end
end

