classdef GGTMFS_Model_Cls < GGTMType_Model_Cls
    %   GGTMFS_Model_Cls 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    
    properties
        Options2    % Options for GGTM-FS parameters
        OutPut      % OutPut structure variable to hold the model type and projection output
    end
    
    methods
        
        % Constructor method to initialize instance variables
        function Obj=GGTMFS_Model_Cls()
            GGTMType_Model_Cls();
            Obj.OutPut.ModelType='GGTMFS';  
            
            Obj.Options2.maxiter = 20;         % Max. no. iterations
            Obj.Options2.verb = 1.0;
            Obj.Options2.tol = 1.0e-7;
            Obj.Options2.ftwt_sup = 1.0;
            Obj.Options2.graph_interval = -1;            
        end
        
        % Set methods to assign the values of the class member variables
        function Obj=SetOPtions2_Maxiter(Obj,OP)
            Obj.Options2.maxiter=OP;
        end        
        function Obj=SetOPtions2_Verb(Obj,OP)
            Obj.Options2.verb=OP;
        end        
        function Obj=SetOptions2_Tol(Obj,OP)
            Obj.Options2.tol=OP;
        end        
        function Obj=SetOptions2.ftwt_sup(Obj,OP)
            Obj.Options2.ftwt_sup=OP;
        end
        function Obj=SetOption2.graph_interval(Obj,OP)
            Obj.Options2.graph_interval=OP;
        end        
        function Obj=SetModelType(Obj,MT)
            Obj.OutPut.ModelType=MT;
        end
        
        % Get methods to obtain the values of instance variables and
        % members of the output structure
        function Obj=GetOPtions2_Maxiter(Obj)
            Obj=Obj.Options2.maxiter;
        end        
        function Obj=GetOPtions2_Verb(Obj)
            Obj=Obj.Options2.verb;
        end        
        function Obj=GetOptions2_Tol(Obj)
            Obj=Obj.Options2.tol;
        end        
        function Obj=GetOptions2_ftwt_sup(Obj)
            Obj=Obj.Options2.ftwt_sup;
        end        
        function Obj=GetOption2_graph_interval(Obj)
            Obj=Obj.Options2.graph_interval;
        end       
        function MT=GetModelType(Obj)
            MT=Obj.OutPut.ModelType;
        end        
        function OutPut=GetOutPut(hObject)
            OutPut=hObject.OutPut;
        end
        function ErrorLog=GetErrorLog(hObject)
            ErrorLog= hObject.OutPut.errlog;
        end
        function Saliencies=GetSal(hObject)
            Saliencies= hObject.OutPut.sal;
        end        
        function y=GetProjected_data(hObject)
            y=hObject.OutPut.y;
        end
        
        %  Function to train GGTM Model for the given dataset
        function hObject = Train_GGTMFS(hObject, handles)
            %TRAIN_GGTMFS  Train GGTM-FS model
            %
            % John R. Owen, NCRG, Aston University, 29 Jul 2009
            %
            % Output:
            % net2          Trained network
            % y             Points to be plotted
            % errlog        Error log
            % sal           Feature saliencies
            %
            
            fprintf('\nTraining GGTM-FS model\n');
            
            % Repeat results
            reset_random();            
          
            % -----------------
            % Init. gtm network
            % -----------------
            
            latgrid = [hObject.No_Latent_Rows, hObject.No_Latent_Rows];         % Latent-space grid layout
            rbfgrid = [hObject.No_RBF_Centres, hObject.No_RBF_Centres];         % RBF-centre grid layout
            latp = prod(latgrid);           % No. latent-space points
            samp_type = 'regular';
            
            % Data array
            data_array = handles.data_array;

            ndata = size(data_array,2);
            dim_data_array = zeros(1,ndata);
            for i=1:ndata
                dim_data_array(i) = data_array{i}.nvar;
            end

            % Mapping function
            map = handles.map;

            % Mixture models array
            mix_array = handles.mix_array;            
            
            % Set up gtm network 
            fs = 1;
            h = findobj('tag', 'FSRCheckBox');
            fsr = get(h,'Value'); % Regularisation with feature saliencies
            hObject.OutPut.net1 = ggtm(hObject.Latent_Dim, latp, dim_data_array, map, mix_array,fs,fsr);
            
            vsrmi = handles.vsrmi;
            if isempty(vsrmi)
                hObject.OutPut.net1 = ggtminit(hObject.OutPut.net1, hObject.Options1, data_array, samp_type, latgrid,rbfgrid);
            else
                hObject.OutPut.net1 = ggtminit(hObject.OutPut.net1, hObject.Options1, data_array, samp_type, latgrid,rbfgrid,vsrmi);
            end
                      
            
            % -----------------
            % Train gtm network
            % -----------------            
            [hObject.OutPut.net2, hObject.OutPut.Options, hObject.OutPut.errlog] = ggtmem(hObject.OutPut.net1, data_array, hObject.Options1);         
            
            % Get coords for plotting
            hObject.OutPut.y = ggtmlmean(hObject.OutPut.net2, data_array);  
            hObject.OutPut.sal = hObject.OutPut.net2.obs_array{1}.Estftwt;
            hObject=hObject.SetTrainingStatus(true);
        end
        
        % Function used to test the given dataset with trained model
        function hObject = Test_GGTMFS(hObject, handles)
            h1=findobj('tag', 'TrainNewModelGUI_Main');
            data_array = getappdata(h1,'data_array');
            mix_array = getappdata(h1,'mix_array');
            
            nb_obs_space = length(hObject.OutPut.net2.obs_array);
            if nb_obs_space ~= length(data_array)
                err_str = ['Error: there should be ' num2str(nb_obs_space) ' observation space(s)'];
                errordlg(err_str)
                error(err_str)
            end
            for i=1:nb_obs_space
               nb_var = hObject.OutPut.net2.obs_array{i}.nin;
               if nb_var ~= data_array{i}.nvar
                   err_str = ['Error: there should be ' num2str(nb_var) ' variables in the observation space #' num2str(i)];
                   errordlg(err_str)
                   error(err_str)
               end
               mix_type = hObject.OutPut.net2.obs_array{i}.mix.type;
               if ~strcmp(mix_type,mix_array{i}.type)
                   err_str = ['Error: the type of mixture in the observation space #' num2str(i) ' should be ' mix_type];
                   errordlg(err_str)
                   error(err_str)                   
               end
            end
            
            hObject.OutPut.y = ggtmlmean(hObject.OutPut.net2, data_array);
        end
       
        % Method to save the model prompting the user for the name of
        % the model with the suggested format
        function hObject=Save_As(hObject,DataFile)
            
            File=fullfile(DataFile.Path,DataFile.Name(1:findstr(DataFile.Name,'.')-1));
            File=[File,'_ggtmfs.mat'];
            TitleString=['Save As (use "', '_ggtmfs.mat','" file extension'];
            
            [hObject.OutPutFile.Name, hObject.OutPutFile.Path]=uiputfile('*.mat',TitleString,File);
            file=fullfile(hObject.OutPutFile.Path,hObject.OutPutFile.Name);
            if (isequal(hObject.OutPutFile.Name,0))
                fprintf('Save As Cancelled');
                hObject=hObject.SetSavedStatus(false);
                return;
            end
            hObject=hObject.Save_Model_Data(file,hObject.GetOutPut());
            hObject=hObject.SetSavedStatus(true);
        end
        
        % Method to load saved trained model
        function [hObject, handles]=Load_Model(hObject,handles)
            % Get the input file name
            [handles.FileName, handles.PathName] = ...
                uigetfile({'*_ggtmfs.mat';'*.mat'}, 'Set Model File');
            if isequal(handles.FileName, 0) || isequal(handles.PathName, 0)
                disp('User pressed cancel');
                return
            else
                fprintf('\nSelected file: %s\n', fullfile(handles.PathName, handles.FileName));
                handles.file=fullfile(handles.PathName,handles.FileName);
                if (isequal(handles.FileName,0))
                    fprintf('Loading Model Cancelled');
                    return;
                end
                hObject=hObject.Load_TrainedModel(handles.file);
                hObject=hObject.SetLoadedStatus(true);
            end
        end
    end   
end

