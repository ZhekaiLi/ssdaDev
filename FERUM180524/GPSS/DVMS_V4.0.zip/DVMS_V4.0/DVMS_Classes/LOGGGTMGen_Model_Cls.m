classdef LOGGGTMGen_Model_Cls   < LOGGGTMType_Model_Cls
    %   LOGGGTMGen_Model_Cls class 
    %   Copyright (C) Shahzad Mumtaz, NCRG, 2011
    properties
        Options2            % Training Algorithms Parameters
    end
    
    methods
         % Constructor method to initialize instance variables
        function Obj=LOGGGTMGen_Model_Cls()
            LOGGGTMType_Model_Cls();
            Obj.Options2=zeros(1,18);            
        end
        
        % Set methods to assign the values of the class member variables        
        function Obj=SetOPtions2(Obj,OP)
            Obj.Options2=OP;
        end
        function Obj=SetIterations(Obj,Iter)
            Obj.Options2(14)=Iter;
        end
        
        % Get methods to obtain the values of instance variables
        function Obj=GetOPtions2(Obj)
            Obj=Obj.Options2;
        end
        function Iter=GetIterations(Obj)
            Iter=Obj.Options2(14);
        end        
    end    
end

