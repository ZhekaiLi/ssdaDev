function [] = dvms()
%DVMS   Data Visualisation and Modelling System
%
% DVMS was written in the NCRG, Aston University, UK, by:
%
% Dharmesh M. Maniyar (2005-08)
% Professor Ian T. Nabney (2005-11)
% John R. Owen (2007-09)
% Shahzad Mumtaz (2010-2011)
% Shahzad Mumtaz, Michel F Randrianandrasana (2014-2015)

clear all
clear variables;   
clc

% Clear for each new run
warning('off', 'all');          % No warnings at all 

% Call add_paths() manually at command line if compiling to a standalone
compile = false;

% Add paths to main search path
if (not(compile))
    add_paths();
end;

% Fix seeds for reproducible results
reset_random(12);

% Start the main dvms gui
TrainNewModelGUI();
