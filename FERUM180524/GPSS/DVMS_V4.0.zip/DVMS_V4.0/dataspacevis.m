function varargout = dataspacevis(varargin)
%DATASPACEVIS M-file for dataspacevis.fig
%
%      H = DATASPACEVIS returns the handle to a new DATASPACEVIS or the handle to
%      the existing singleton*.
%
%      DATASPACEVIS('Property','Value',...) creates a new DATASPACEVIS using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to dataspacevis_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      DATASPACEVIS('CALLBACK') and DATASPACEVIS('CALLBACK',hObject,...) call the
%      local function named CALLBACK in DATASPACEVIS.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% (C) Dharmesh Maniyar,  2006
% Copyright (C) Shahzad Mumtaz, Michel F Randrianandrasana (2014-2015)

% Last Modified by GUIDE v2.5 31-Mar-2011 19:40:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @dataspacevis_OpeningFcn, ...
                   'gui_OutputFcn',  @dataspacevis_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before dataspacevis is made visible.
function dataspacevis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for dataspacevis

handles.output = hObject;
Visualize_Axes = varargin{4};
handles.UserData = varargin{2};
nsel = size(handles.UserData.Data.Values,1); % Number of selected points

currWindow = findobj('Tag','DataSpaceVis');
set(currWindow,'Name','Local parallel coordinates window ');
set(currWindow,'Tag','DataSpaceVis');


DataAxs = findobj('Tag', 'DataAxs');

set(DataAxs, 'YLim', handles.UserData.Data.GetRange_Values());
set(DataAxs, 'XLim', [1, handles.UserData.Data.GetNo_DataColumns()]);
set(DataAxs, 'XTick', [1:1:handles.UserData.Data.GetNo_DataColumns()]);
range=handles.UserData.Data.GetRange_Values();
set(DataAxs, 'YTick', [range(1):1:range(2)]);
 
InfosAxs = findobj('Tag','InfosAxs');

handles.Position_InfoAxs=get(InfosAxs,'position');
% Actually second time when the function is called it become a cell array
% preserving the previous rows generated whereas we require a numeric array
% here to generate the new window 
if size(handles.Position_InfoAxs,1)>1 
    handles.Position_InfoAxs(1:size(handles.Position_InfoAxs,1)-1,:)=[];
    handles.Position_InfoAxs=cell2mat(handles.Position_InfoAxs);
end

handles.Position_InfoAxs_Pnl=get(findobj('Tag','InfosAxs_Pnl'),'position');
if size(handles.Position_InfoAxs_Pnl,1)>1 
    handles.Position_InfoAxs_Pnl(1:size(handles.Position_InfoAxs_Pnl,1)-1,:)=[];
    handles.Position_InfoAxs_Pnl=cell2mat(handles.Position_InfoAxs_Pnl);
end       
if nsel >14 
   set(findobj('Tag', 'InfosAxs_Sld'),'visible','on',...
       'value',nsel-14+1,'min',0,'max',nsel-14+1,...
       'sliderstep',[1/(nsel-14) 1/((nsel-14)/2)]);   
else
   set(findobj('Tag', 'InfosAxs_Sld'),'visible','off');          
end

SinglePointHeight=handles.Position_InfoAxs(4)/10;
handles.Position_InfoAxs(2)=handles.Position_InfoAxs(2)-(SinglePointHeight*nsel-SinglePointHeight*10);
handles.Position_InfoAxs(4)=SinglePointHeight*nsel;

set(findobj('Tag', 'InfosAxs'),'position',handles.Position_InfoAxs);
set(findobj('Tag', 'InfosAxs_Pnl'),'position',handles.Position_InfoAxs_Pnl);

set(findobj('Tag', 'InfosAxs_Pnl'),'position',handles.Position_InfoAxs_Pnl);

handles.Position_DataAxs=get(findobj('Tag', 'DataAxs'),'position');
if size(handles.Position_DataAxs,1)>1 
handles.Position_DataAxs(1:size(handles.Position_DataAxs,1)-1,:)=[];
handles.Position_DataAxs=cell2mat(handles.Position_DataAxs);
end       

handles.Position_DataAxs_Pnl=get(findobj('Tag', 'DataAxs_Pnl'),'position');
if size(handles.Position_DataAxs_Pnl,1)>1 
handles.Position_DataAxs_Pnl(1:size(handles.Position_DataAxs_Pnl,1)-1,:)=[];
handles.Position_DataAxs_Pnl=cell2mat(handles.Position_DataAxs_Pnl);
end       

if handles.UserData.Data.GetNo_DataColumns() >12 
   set(findobj('Tag', 'DataAxs_Sld'),'visible','on',...
       'value',0,'min',0,'max',handles.UserData.Data.GetNo_DataColumns()-12,...
       'sliderstep',[1/(handles.UserData.Data.GetNo_DataColumns()-12) 1/((handles.UserData.Data.GetNo_DataColumns()-12)/2)]);  
else
   set(findobj('Tag', 'DataAxs_Sld'),'visible','off');

end
SingleVariableWidth=handles.Position_DataAxs(3)/12;
handles.Position_DataAxs(3)=handles.Position_DataAxs(3)+(SingleVariableWidth*handles.UserData.Data.GetNo_DataColumns()-SingleVariableWidth*12);


set(findobj('Tag', 'DataAxs'),'position',handles.Position_DataAxs);
set(findobj('Tag', 'DataAxs_Pnl'),'position',handles.Position_DataAxs_Pnl);         

set(findobj('Tag', 'DataAxs_Pnl'),'position',handles.Position_DataAxs_Pnl);
DataAxs_Position=get(findobj('Tag','DataAxs_Pnl'),'position');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes dataspacevis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = dataspacevis_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function InfosAxs_Sld_Callback(hObject, eventdata, handles)
% hObject    handle to InfosAxs_Sld (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
nsel = size(handles.UserData.Data.Values,1); % Number of selected points
diff=get(hObject,'max')-ceil(get(hObject,'value'));
temp_position=handles.Position_InfoAxs;
temp_position(2)=temp_position(2)+diff*(temp_position(4)/(nsel));
set(findobj('Tag','InfosAxs'),'position',temp_position);


% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function InfosAxs_Sld_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InfosAxs_Sld (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function DataAxs_Sld_Callback(hObject, eventdata, handles)
% hObject    handle to DataAxs_Sld (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

diff=get(hObject,'min')-ceil(get(hObject,'value'));
temp_position=handles.Position_DataAxs;
temp_position(1)=temp_position(1)+diff*(temp_position(3)/size(handles.UserData.Data.Values,2));
set(findobj('Tag','DataAxs'),'position',temp_position);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function DataAxs_Sld_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DataAxs_Sld (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on mouse press over axes background.
function InfosAxs_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to InfosAxs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
