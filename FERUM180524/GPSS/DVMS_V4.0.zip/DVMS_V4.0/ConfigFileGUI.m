function varargout = ConfigFileGUI(varargin)
% CONFIGFILEGUI M-file for ConfigFileGUI.fig
%      CONFIGFILEGUI, by itself, creates a new CONFIGFILEGUI or raises the existing
%      singleton*.
%
%      H = CONFIGFILEGUI returns the handle to a new CONFIGFILEGUI or the handle to
%      the existing singleton*.
%
%      CONFIGFILEGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONFIGFILEGUI.M with the given input arguments.
%
%      CONFIGFILEGUI('Property','Value',...) creates a new CONFIGFILEGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ConfigFileGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ConfigFileGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ConfigFileGUI

% Last Modified by GUIDE v2.5 28-Jun-2011 23:34:36

% Begin initialization code - DO NOT EDIT
%   Copyright (C) Shahzad Mumtaz, NCRG, 2011

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ConfigFileGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ConfigFileGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ConfigFileGUI is made visible.
function ConfigFileGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ConfigFileGUI (see VARARGIN)

% Choose default command line output for ConfigFileGUI
handles.output = hObject;
%---------------------------------------------------------------------------------------------------------------------------------
% Disable the save buttons on opening configuration file GUI
%---------------------------------------------------------------------------------------------------------------------------------
set(handles.SaveConfig_Btn,'enable','off')
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ConfigFileGUI wait for user response (see UIRESUME)
% uiwait(handles.ConfigFileGUI);


% --- Outputs from this function are returned to the command line.
function varargout = ConfigFileGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
guidata(hObject, handles);


% --- Executes on button press in LoadConfig_Btn.
%---------------------------------------------------------------------------------------------------------------------------------------
% The following call back is called when user loads an existing
% configuration file
%---------------------------------------------------------------------------------------------------------------------------------------

function LoadConfig_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to LoadConfig_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%---------------------------------------------------------------------------------------------------------------------------------------
% Instantiating Configuration class object that would hold all the
% parameters of the files
%---------------------------------------------------------------------------------------------------------------------------------------
handles.Config=Config_Cls();

%---------------------------------------------------------------------------------------------------------------------------------------
% Load existing configuration file
%---------------------------------------------------------------------------------------------------------------------------------------
[handles.ConfigFile.Name, handles.ConfigFile.Path] =  uigetfile('*.cfg', 'Set Configuration File');
   if (isequal(handles.ConfigFile.Name, 0) || isequal(handles.ConfigFile.Path, 0))
       disp('The user pressed cancel');
       return;
   else
%---------------------------------------------------------------------------------------------------------------------------------------
% Reading configuration file and assiging the parameters of the
% configuration file to GUI controls of configuration GUI
%---------------------------------------------------------------------------------------------------------------------------------------
        handles.Config=handles.Config.ReadConfigurationFile(fullfile(handles.ConfigFile.Path, handles.ConfigFile.Name)); 
        
        set(handles.DatabaseName_Txt,'String',handles.Config.GetTrain_DS_Name());
        set(handles.Novariables_Txt,'String',handles.Config.GetNo_Variables());
        set(handles.Nolabels_Txt,'String',handles.Config.GetNo_Labels());
        set(handles.Labelnames_Lst,'String',handles.Config.GetLabel_Names);
        set(handles.Labelcolindx_Txt,'String',handles.Config.GetLabels_ColIndx());
        set(handles.Titlerowindx_Cmb,'Value',handles.Config.GetTitle_RowIndx()+1);
        
        set(handles.Idcolstat_Cmb,'Value',handles.Config.GetID_ColIndxstat()+1);
 % Checking the Presence of the ID column if it is present display the ID
 % column textbox with label with default value
        if (get(handles.Idcolstat_Cmb,'Value')==2)
            set(handles.Idcolindx_Txt,'Visible','on');
            set(handles.Idcolindx_Lbl,'Visible','on');
            set(handles.Idcolindx_Txt,'String',handles.Config.GetID_ColIndx());
        end;    
        set(handles.Normalization_Cmb,'Value',handles.Config.GetNormalization()+1);
        set(handles.Target_Cmb,'Value',handles.Config.GetTarget_ColIndx()+1);
        
% In case of presence of target column in the configuration file turn on the bin-limits control button with set bin limits button to load the files         
        if (handles.Config.GetTarget_ColIndx>0)
            Target_Cmb_Callback(hObject, eventdata, handles);
        end
        set(handles.Fngprncolindx_Txt,'String',handles.Config.GetFngPrn_ColIndx());
   end
guidata(hObject, handles);











% --- Executes during object creation, after setting all properties.
function DatabaseName_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DatabaseName_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes during object creation, after setting all properties.
function Novariables_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Novariables_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Nolabels_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Nolabels_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Nolabels_Txt as text
%        str2double(get(hObject,'String')) returns contents of Nolabels_Txt as a double
disp('')

% --- Executes during object creation, after setting all properties.
function Nolabels_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Nolabels_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Labelnames_Lst.
function Labelnames_Lst_Callback(hObject, eventdata, handles)
% hObject    handle to Labelnames_Lst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Labelnames_Lst contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Labelnames_Lst


% --- Executes during object creation, after setting all properties.
function Labelnames_Lst_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Labelnames_Lst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Addlabelname_Btn.
function Addlabelname_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Addlabelname_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Retaining the list of lables and adding the new string at the end in list
% box control
s=get(handles.Labelnames_Lst,'String');
num=size(s,1)
if num==0 
    s=inputdlg('Enter the Label', 'Label Name');
else
    s(num+1)=inputdlg('Enter the Label', 'Label Name');
end
set(handles.Labelnames_Lst,'String',s);
guidata(hObject,handles)



function Labelcolindx_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Labelcolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Labelcolindx_Txt as text
%        str2double(get(hObject,'String')) returns contents of Labelcolindx_Txt as a double
disp('')

% --- Executes during object creation, after setting all properties.
function Labelcolindx_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Labelcolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Titlerowindx_Cmb_Callback(hObject, eventdata, handles)
% hObject    handle to Titlerowindx_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Titlerowindx_Cmb as text
%        str2double(get(hObject,'String')) returns contents of Titlerowindx_Cmb as a double
disp('')

% --- Executes during object creation, after setting all properties.
function Titlerowindx_Cmb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Titlerowindx_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Idcolstat_Cmb_Callback(hObject, eventdata, handles)
% hObject    handle to Idcolstat_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Idcolstat_Cmb as text
%        str2double(get(hObject,'String')) returns contents of Idcolstat_Cmb as a double
% Displaying the ID column index text box if the ID column status is
% set to be yes otherwise hiding the ID column Index 
switch get(handles.Idcolstat_Cmb,'Value')   
    case 1
         set(handles.Idcolindx_Lbl,'Visible','off')
         set(handles.Idcolindx_Txt,'Visible','off')
    case 2
         set(handles.Idcolindx_Lbl,'Visible','on')
         set(handles.Idcolindx_Txt,'Visible','on')
    otherwise
end


% --- Executes during object creation, after setting all properties.
function Idcolstat_Cmb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Idcolstat_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Normalization_Cmb.
function Normalization_Cmb_Callback(hObject, eventdata, handles)
% hObject    handle to Normalization_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Normalization_Cmb contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Normalization_Cmb
disp('')


% --- Executes during object creation, after setting all properties.
function Normalization_Cmb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Normalization_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fngprncolindx_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Fngprncolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fngprncolindx_Txt as text
%        str2double(get(hObject,'String')) returns contents of Fngprncolindx_Txt as a double
disp('')

% --- Executes during object creation, after setting all properties.
function Fngprncolindx_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fngprncolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ModifyConf_Btn.
function ModifyConf_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to ModifyConf_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in GenerateConfig_Btn.
function GenerateConfig_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to GenerateConfig_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Creating a Config_Cls object and calling its constructor to initialize it
% with the default parameters and then setting these parameter values to
% the configuration file generation GUI

%---------------------------------------------------------------------------------------------------------------------------------------
% Instantiating Configuration class object and assigning default parameters
% of the object variables to the controls of the configuration GUI controls
%---------------------------------------------------------------------------------------------------------------------------------------

handles.Config=Config_Cls();

set(handles.DatabaseName_Txt,'String',handles.Config.GetTrain_DS_Name());
set(handles.Novariables_Txt,'String',handles.Config.GetNo_Variables());
set(handles.Nolabels_Txt,'String',handles.Config.GetNo_Labels());
set(handles.Labelnames_Lst,'String','');
set(handles.Labelcolindx_Txt,'String',handles.Config.GetLabels_ColIndx());
set(handles.Titlerowindx_Cmb,'Value',handles.Config.GetTitle_RowIndx()+1);

set(handles.Idcolstat_Cmb,'Value',handles.Config.GetID_ColIndxstat()+1);
set(handles.Idcolindx_Txt,'String',handles.Config.GetID_ColIndx());

set(handles.Normalization_Cmb,'Value',handles.Config.GetNormalization()+1)
set(handles.Target_Cmb,'Value',handles.Config.GetTarget_ColIndx()+1)
set(handles.Fngprncolindx_Txt,'String',handles.Config.GetFngPrn_ColIndx())

set(handles.BinLim_Txt,'String','')

set(handles.Idcolindx_Lbl,'Visible','off')
set(handles.Idcolindx_Txt,'Visible','off')    
set(handles.BinLim_Btn,'Visible','off');

%---------------------------------------------------------------------------------------------------------------------------------
% Enable the save buttons on opening configuration file GUI
%---------------------------------------------------------------------------------------------------------------------------------
set(handles.SaveConfig_Btn,'enable','on')
guidata(hObject, handles);

% --- Executes on button press in SaveConfig_Btn.
function SaveConfig_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to SaveConfig_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%---------------------------------------------------------------------------------------------------------------------------------------
% Saving the curent values of the form the controls on the Configuration
% object and then then saving the Configuration class by calling objects
% member function
%---------------------------------------------------------------------------------------------------------------------------------------
handles.Config=handles.Config.SetTrain_DS_Name(get(handles.DatabaseName_Txt,'String'));
handles.Config=handles.Config.SetNo_Variables(str2num(get(handles.Novariables_Txt,'String')));
handles.Config=handles.Config.SetNo_Labels(str2num(get(handles.Nolabels_Txt,'String')));
handles.Config=handles.Config.SetLabel_Names(get(handles.Labelnames_Lst,'String'));
handles.Config=handles.Config.SetLabels_ColIndx(str2num(get(handles.Labelcolindx_Txt,'String')));
handles.Config=handles.Config.SetTitle_RowIndx(get(handles.Titlerowindx_Cmb,'Value')-1);

handles.Config=handles.Config.SetID_ColIndxstat(get(handles.Idcolstat_Cmb,'Value')-1);
handles.Config=handles.Config.SetID_ColIndx(str2num(get(handles.Idcolindx_Txt,'String')));

handles.Config=handles.Config.SetNormalization(get(handles.Normalization_Cmb,'Value')-1);
handles.Config=handles.Config.SetFngPrn_ColIndx(str2num(get(handles.Fngprncolindx_Txt,'String')));

[handles.ConfigFile.Name, handles.ConfigFile.Path] =  uiputfile('*.cfg', 'Set Configuration File');
  % Save the Configuration Object in a file specialied in the open dialog box with the specified name and abort the saving process if user pressed the cancel button 
  if (isequal(handles.ConfigFile.Name, 0) || isequal(handles.ConfigFile.Path, 0))
       disp('The user pressed cancel');
       return;
  else
       handles.Config=handles.Config.WriteconfigurationFile(fullfile(handles.ConfigFile.Path, handles.ConfigFile.Name)); 
  end   
guidata(hObject, handles);


% --- Executes on button press in Ok_Btn.
function Ok_Btn_Callback(hObject, eventdata, handles,varargin)
% hObject    handle to Ok_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=findobj('tag', 'ObsSpaceGUI');

if (isfield(handles,'Config') && isfield(handles,'ConfigFile'))
    if strcmp(get(h,'Visible'),'off') || isempty(h)
        h1=findobj('tag', 'TrainNewModelGUI_Main');
        setappdata(h1,'ConfigFilePath',handles.ConfigFile.Path);
        setappdata(h1,'ConfigFileName',handles.ConfigFile.Name);
        setappdata(h1,'GUI_Config',handles.Config);    
        h2=findobj('tag', 'LoadDataBtn');
        set(h2,'Enable','on');
    else
        setappdata(h,'ConfigFilePath',handles.ConfigFile.Path);
        setappdata(h,'ConfigFileName',handles.ConfigFile.Name);
        setappdata(h,'GUI_Config',handles.Config); 
        h2=findobj('tag', 'OSLoadDataBtn');
        set(h2,'Enable','on');
        h3=findobj('tag', 'OkBtn');
        set(h3,'Enable','off')
    end    
end

guidata(hObject, handles);
close(handles.ConfigFileGUI)



% --- Executes on button press in Cancel_Btn.
function Cancel_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Cancel_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on Novariables_Txt and none of its controls.
function Novariables_Txt_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to Novariables_Txt (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over Novariables_Txt.
function Novariables_Txt_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to Novariables_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (eventdata.Novariables_Txt.Character>='0' && eventdata.Novariables_Txt.Character<='9')
    eventdata.Novariables_Txt.Character='';
end


% --- Executes on button press in Removelabelname_Btn.
function Removelabelname_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to Removelabelname_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%--------------------------------------------------------------------------------------------------------------------------
% Removing the selected Label from the available list of items
%--------------------------------------------------------------------------------------------------------------------------
selected = get(handles.Labelnames_Lst,'Value'); 
prev_str = get(handles.Labelnames_Lst, 'String'); 
if ~isempty(prev_str) 
    prev_str(get(handles.Labelnames_Lst,'Value')) = []; 
    set(handles.Labelnames_Lst, 'String', prev_str, ... 
        'Value', min(selected,length(prev_str))); 
end 


% --- Executes during object deletion, before destroying properties.
function ConfigFileGUI_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to ConfigFileGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when user attempts to close ConfigFileGUI.


% --- Executes when user attempts to close ConfigFileGUI.
function ConfigFileGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to ConfigFileGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

%-----------------------------------------------------------------------------------------------------------
% Saving the Configuration File Object, Configuration File Path and
% Configuration File Name at the application level
%-----------------------------------------------------------------------------------------------------------

h=findobj('tag', 'ObsSpaceGUI');

if (isfield(handles,'Config') && isfield(handles,'ConfigFile'))
    if strcmp(get(h,'Visible'),'off') || isempty(h)
        h1=findobj('tag', 'TrainNewModelGUI_Main');
        setappdata(h1,'ConfigFilePath',handles.ConfigFile.Path);
        setappdata(h1,'ConfigFileName',handles.ConfigFile.Name);
        setappdata(h1,'GUI_Config',handles.Config);        
    else
        setappdata(h,'ConfigFilePath',handles.ConfigFile.Path);
        setappdata(h,'ConfigFileName',handles.ConfigFile.Name);
        setappdata(h,'GUI_Config',handles.Config);         
    end    
end

delete(hObject);


% --- Executes on key press with focus on Idcolstat_Cmb and none of its controls.
function Idcolstat_Cmb_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to Idcolstat_Cmb (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)



function Idcolindx_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Idcolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Idcolindx_Txt as text
%        str2double(get(hObject,'String')) returns contents of Idcolindx_Txt as a double
disp('')

% --- Executes during object creation, after setting all properties.
function Idcolindx_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Idcolindx_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DatabaseName_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to DatabaseName_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DatabaseName_Txt as text
%        str2double(get(hObject,'String')) returns contents of DatabaseName_Txt as a double
disp('')



function Novariables_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to Novariables_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Novariables_Txt as text
%        str2double(get(hObject,'String')) returns contents of Novariables_Txt as a double
disp('')


% --- Executes on selection change in Target_Cmb.
function Target_Cmb_Callback(hObject, eventdata, handles)
% hObject    handle to Target_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
switch get(handles.Target_Cmb,'Value')   
    case 1    % Case when there are no target column in the data file
         handles.Config=handles.Config.SetTarget_ColIndx(0);
         set(handles.BinLim_Btn,'Visible','off');
         set(handles.BinLim_Txt,'String','');
         x=get(handles.Target_Cmb,'Value');
    case 2    % Case when there are target column in the data file, so setting the Bin limits values and enabling the set bin limits button 
        handles.Config=handles.Config.SetTarget_ColIndx(1);
        x=get(handles.Target_Cmb,'Value');
        set(handles.BinLim_Btn,'Visible','on');
         set(handles.BinLim_Txt,'Enable','on');
         h1=handles.Config.GetBin_Lim();
        h2 = cell(5, 1);
        for i = 1:5;
            h2{i} = num2str(h1(i));
        end;
        str1 = [h2{1}, ' - ', h2{2}, ' - ', h2{3}, ' - ', h2{4}, ' - ', h2{5}];
        h2 = findobj('tag', 'BinLim_Txt');
        set(h2, 'string', str1);
    otherwise
end
guidata(hObject, handles);
% Hints: contents = cellstr(get(hObject,'String')) returns Target_Cmb contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Target_Cmb


% --- Executes during object creation, after setting all properties.
function Target_Cmb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Target_Cmb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end;


% --- Executes on button press in BinLim_Btn.
function BinLim_Btn_Callback(hObject, eventdata, handles)
% hObject    handle to BinLim_Btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%---------------------------------------------------------------------------------------------------------------------------
% Retrieving the bin limit values from the configuration object and then
% prompting the user to enter the new limits
%---------------------------------------------------------------------------------------------------------------------------
binlim = handles.Config.GetBin_Lim();
% Get new limits from user
[x1, s1] = set_bin_limits(binlim);
handles.Config=handles.Config.SetBin_Lim(x1);
    h1=handles.Config.GetBin_Lim();
    h2 = cell(5, 1);
    for i = 1:5;
        h2{i} = num2str(h1(i));
    end;
    str1 = [h2{1}, ' - ', h2{2}, ' - ', h2{3}, ' - ', h2{4}, ' - ', h2{5}];
    h2 = findobj('tag', 'BinLim_Txt');
    set(h2, 'string', str1);
guidata(hObject, handles);





function BinLim_Txt_Callback(hObject, eventdata, handles)
% hObject    handle to BinLim_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BinLim_Txt as text
%        str2double(get(hObject,'String')) returns contents of BinLim_Txt as a double


% --- Executes during object creation, after setting all properties.
function BinLim_Txt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BinLim_Txt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
