function togglelinevisu(TheLine)
% To provide toggle for line and bar charts for data space visualisation 

%  (C) Dharmesh Maniyar,  2006
 
    PatterLineTag = ['PatternLine', TheLine];
    PatterTextTag = ['PatternText', TheLine];

    switch get(gcf,'SelectionType')
     case 'alt' %the right mouse button
        set(findobj('Tag', PatterLineTag), 'Visible', 'off');
        set(findobj('Tag', PatterTextTag), 'Visible', 'off');
     case 'normal'  %the left  mouse button
        set(findobj('Tag', PatterLineTag), 'Visible', 'on');
        set(findobj('Tag', PatterTextTag), 'Visible', 'on');
    end
