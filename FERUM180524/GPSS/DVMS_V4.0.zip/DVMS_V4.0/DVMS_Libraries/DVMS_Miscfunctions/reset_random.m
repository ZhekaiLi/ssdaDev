function [] = reset_random(randomnumber)
%RESET_RANDOM   Reset random number generator
%
% John R. Owen, NCRG, 11 Mar 2009
%

% Seed random no. generator for reproducible results
if nargin==1
    seed = randomnumber;    
else
    seed = 1729;        
end
rng(seed,'twister') 


