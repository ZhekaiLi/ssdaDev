function matincsv=mat2csv(mat)
% Converts a matrix into csv format which can be used for clipboarding.

strmat = mat2str(mat);
strmat1 = regexprep(strmat,'[\[\]]','');
matincsv = regexprep(strmat1,'\s',',');

