function [x2, s1] = set_bin_limits(x1)
%SET_BIN_LIMITS     Set bin-limits
%
% John R. Owen, NCRG, 31 Mar 2009
%
%
% Existing limits are in x1.
% If user enters limits incorrectly, limits are returned unchanged.
% Numeric limits are returned in x2, string version (cell) in s1
%


str1 = 'Enter limit 1 (highest):';
str2 = 'Limit 2:';
str3 = 'Limit 3:';
str4 = 'Limit 4:';
str5 = 'Limit 5 (lowest):';
str6 = 'Bin-Limits';
str1 = {str1, str2, str3, str4, str5};

% Convert bin-limits to string
reply = cell(1,5);
for i = 1:5;
    reply{i} = num2str(x1(i));
end;

% Read the limits from input dialog
numlines = 1;               % 1 line per text-entry box
h2 = inputdlg(str1, str6, numlines, reply);
if (isempty(h2))            % User pressed cancel?
    x2 = x1;                % Yes => don't change value of bin limits
    s1 = lim_string(x1);    % Return string version
    return;                 % Exit
else
    x2 = str2double(h2);    % Convert to numerical values
end;

% Any inputs NaN?
if (any(isnan(x2)))
    msgbox('Error: invalid number(s) entered', 'Input Error', 'error');
    x2 = x1;                % Yes => don't change value of bin limits
    s1 = lim_string(x1);    % Return string version
    return;                 % Exit
end;

% Check to ensure limits entered in descending order
t1 = (x2(1) > x2(2));
t2 = (x2(2) > x2(3));
t3 = (x2(3) > x2(4));
t4 = (x2(4) > x2(5));
t1 = (t1 & t2 & t3 & t4);
if (~t1)
    str1 = sprintf('Input Error\n');
    str2 = sprintf('Limits (L) must be entered in descending order:\n');
    str3 = sprintf('L1 > L2 > L3 > L4 > L5\n');
    str1 = [str1, str2, str3];
    msgbox(str1, 'Input Error', 'error');
    x2 = x1;                % Don't change value of bin limits
    s1 = lim_string(x1);    % Return string version
    return;                 % Exit
end;


% Successful input
% Return numeric limits in x2, and string version in s1
s1 = lim_string(x2);
return;



% ---------------------------------------------------
% Local function: Convert x2 to cell array of strings
% ---------------------------------------------------

function [s1] = lim_string(x2)

nlim = length(x2);
s1 = cell(nlim, 1);
for i = 1:nlim;
    s1{i} = num2str(x2(i));
end;



