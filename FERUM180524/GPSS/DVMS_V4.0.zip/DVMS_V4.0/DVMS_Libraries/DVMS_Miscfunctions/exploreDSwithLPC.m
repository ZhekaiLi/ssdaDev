function exploreDSwithLPC(UserData,Visualize_Axes)
% Allows exploration of latent space. 
% UserData is a structure.
% LatentSpaceAxs is the axes which you want to explore.
% (C) Copyright Dharmesh Maniyar 2006

  disp('the mouse loop started');
  % Loop until the right mouse button is switched
  UserData.pattern.button = 1;
  %  mydebug2([' the tag ',get(findobj('Tag',LatentSpaceAxs),'tag')]);
  if ~sum(strcmp(Visualize_Axes,get(findobj('Tag',Visualize_Axes),'tag')))  
      mydebug([Visualize_Axes ' dose not exist. Please do not close the ' ...
               'latent space visualisation plot.']);
      return;
  end    
  disp('-----Explore the latent space projection using local parallel coordinates technique-------');
  disp('Left click a point in the latent space projection to obtain its corresponding LPC.');
  disp('Middle click (or ''n'' + left click) in the latent space projection for a new LPC window.');
  disp('Right click on the IDs in the LPC plots to see the actual values of different properties of that point.');
  disp('------------------------------------------------------------------------------------');
  disp(['Right click in the latent space projection when ' ...
           'finished exploring latent space plot using the local parallel coordinates.']);
  
  UserData.pattern.dswindow = 1; % data space window number

  
  while UserData.pattern.button ~= 3 % when right click - exit
                                     % Cursor position 
                         
      if ~sum(strcmp('Visualize_Axes',get(findobj('Tag',Visualize_Axes),'tag')))
                  figure(findobj('Tag', Visualize_Axes)); 
      else 
          axes(findobj('Tag', Visualize_Axes)); 
      end
      EmptyButton = 1;
      while EmptyButton
          [UserData.pattern.X, UserData.pattern.Y, UserData.pattern.button] = ...
              ginput(1); % get user input
          EmptyButton = isempty(UserData.pattern.button);
      end   
 
      if ~sum(strcmp(Visualize_Axes,get(findobj('Tag',Visualize_Axes),'tag')))  
          mydebug(['LatentVis dose not exist. Please do not close the ' ...
                   'latent space visualisation plot.']);
          return;
      end
      %UserData.pattern.button
      temphandles.UserData = UserData;                  
      if UserData.pattern.button == 1 | UserData.pattern.button == 32 
        if ~sum(strcmp(['DataAxs' num2str(UserData.pattern.dswindow)],get(findobj('Tag',['DataAxs' num2str(UserData.pattern.dswindow)]),'Tag')))  
          dataspacevis('Struct',UserData,'String',Visualize_Axes);  
          
%          mydebug('The Data space window dose not exist.');
%              return;
        else
            if get(findobj('Tag','MultipleLPC_Btn'),'value')
                UserData.pattern.dswindow = UserData.pattern.dswindow+1;
                dataspacevis('Struct',UserData,'String',Visualize_Axes);
                temphandles.UserData = UserData;  
            end
        end
          ddvs_dataplot(temphandles,'pattern',Visualize_Axes);
          
%      elseif UserData.pattern.button == 11
%          print('latent.eps', '-deps2c')
      elseif UserData.pattern.button == 2 | UserData.pattern.button == 110
          % middle mouse button or 'n' + left mouse. To get new
          % dataspace window  
          UserData.pattern.dswindow = UserData.pattern.dswindow+1;
          dataspacevis('Struct',UserData,'String',Visualize_Axes);
          temphandles.UserData = UserData;                  
          ddvs_dataplot(temphandles,'pattern',Visualize_Axes);
      end
      
  end
  
  % close all the lpc windows which were created
  for dswindowNo = 1:1:UserData.pattern.dswindow
     close(findobj('Tag',['DataSpaceVis' num2str(dswindowNo)]));
  end