function Visualize = plot_binned_points2(x, t, binlim,tn)
%PLOT_BINNED_POINTS   Plot Binned Points
%
% Bin points according to bin-limits and plot the points
%
% John R. Owen, NCRG, 8 Mar 2009
%


% Easy-access local parameters
% % % % % % % % % % % %binlim = fparam.binlim;
% % % % % Commented for the time being to fix the name of the target Shahzad Mumtaz
% % % % tn = fparam.targetname;

% Set axes to main plot axes
ax1 = findobj('tag', 'Visualize_AxesSelection');
if (gca ~= ax1)
    set(gcf, 'currentaxes', ax1);
end;
cla;    % Clear main axes

% Parameterise points to plot
nmstyle = 5;                        % No. of marker styles
marker = blanks(nmstyle);           % Marker type
msize = zeros(nmstyle, 1);          % Marker size
clr = zeros(nmstyle, 3);            % Marker colour
mfclr = zeros(nmstyle, 3);          % Marker face colour

% Load marker types
marker(1) = 'o';
marker(2) = 'o';
marker(3) = 'o';
marker(4) = 'o';
marker(5) = 's';

% Load marker sizes
msize(:, 1) = 3;

% Load marker colours
clr(1, :) = [1, 0, 0];                  % Red
clr(2, :) = [0, 0, 0];                  % Black
clr(3, :) = [0.000, 0.784, 0.784];      % Light blue
clr(4, :) = [0, 1, 0];                  % Green
clr(5, :) = [0, 0, 0];                  % Black (border)

% Load marker face colours
for i = 1:nmstyle;
    mfclr(i, :) = clr(i, :);
end;
% Yellow face colour for outside range
mfclr(5, :) = [1.000, 0.862, 0.000];







% --------------------
% Plot the data points
% --------------------

% Put each point into a bin depending on its activity/target value
lenx = size(x,1);
ptc = zeros(lenx, 1);   % Bin for each point  

% Local variables to hold bin-limits
t1 = binlim(1);
t2 = binlim(2);
t3 = binlim(3);
t4 = binlim(4);
t5 = binlim(5);

% Bin each point by its activity value
for i = 1:lenx;
    h1 = t(i);
    if ((h1 > t1) || (h1 < t5))
        ptc(i) = 5;         % Outside bin-limits
    elseif (h1 >= t2)
        ptc(i) = 1;         % Bin 1
    elseif (h1 >= t3)
        ptc(i) = 2;         % Bin 2
    elseif (h1 >= t4)
        ptc(i) = 3;         % Bin 3
    else
        ptc(i) = 4;         % Otherwise bin 4
    end;
end;


% Set axes to main plot axes
if (gca ~= ax1)
    set(gcf, 'currentaxes', ax1);
end;
cla;

% Hold all points on the plot
hold on;



% ---------------
% Plot the points
% ---------------

% Plot most active last ensuring these are always plotted
% on top of all other points

for i = nmstyle:-1:1;
    for j = 1:lenx;
        h1 = ptc(j);
        if (h1 == i)
            h2 = plot(x(j, 1), x(j, 2), 'd');
            set(h2, 'marker', marker(h1), 'markersize', msize(h1));
            set(h2, 'color', clr(h1, :), 'markerfacecolor', mfclr(h1, :));
        end;
    end;    
end;
legboxcol = [1 1 1];
set(gca,'XColor',legboxcol);
set(gca,'YColor',legboxcol);
set(gca,'Color',legboxcol);
axis('square');
set(gca, 'Box', 'On')
%set(gca, 'ytick', [], 'xtick', []);
hold on;

drawnow;





