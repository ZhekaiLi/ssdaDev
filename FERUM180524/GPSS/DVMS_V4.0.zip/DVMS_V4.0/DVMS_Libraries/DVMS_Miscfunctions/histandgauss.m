function histAndGauss(data,header_str,binsize,cutoff) 
% Draws histograms (2 variables per figure) for each variables in the
% data matrix passed. Each column will be considered as separate variable.
% It also draws Gaussian fit on the data.
% binsize - Binsize to be used while drawing the histogram default 60
% cutoff - Exclude the % of outlier from beginig and ending of the sorted
% data. Default 0%
%  (C) Dharmesh Maniyar,  2006

if nargin < 3
    binsize = 60;
else
    binsize = binsize;
end
if nargin < 4
    cutoff = 0;
else
    cutoff = floor(size(data(:,1),1) * cutoff); % cutoff should be
                                                    % between 0 and 1
end

no_variables = size(data,2);

index = 1;

figure;
hold on

sr = ceil(sqrt(no_variables));
while index <= no_variables
    %    for n = 1:2
    %    if index > no_variables
    %       break;
    %    end
        thedata = sort(data(cutoff+1:end-cutoff-1, index));
        %                [prepoc, thedata] = normal(sort(data.val(cutoff:end-cutoff,index)));
        size(thedata);
        d_min = min(thedata);
        d_max = max(thedata);
        
        subplot(sr,sr,index);
        %    histp(thedata,d_min,d_max,binsize);
        hist(thedata,binsize);
        %newname = data.header_str(index);
        newname =  regexprep(header_str{index}, 'ponse', 'ponse"');
        newname =  regexprep(newname, '%', '"% ');
        newname =  regexprep(newname, ']', '] ');
        newname =  regexprep(newname, '_', ' ');
        title(newname);
        xlabel('Normalised value');
        ylabel('Frequency');
        %     mu = mean(thedata);
   %     v = var(thedata);
   %     y = gauss(mu,v,(d_min:.1:d_max)');
   %     hold on;
   %     plot(d_min:.1:d_max,y,'r-.');
        index = index +1;        
        % end
end
