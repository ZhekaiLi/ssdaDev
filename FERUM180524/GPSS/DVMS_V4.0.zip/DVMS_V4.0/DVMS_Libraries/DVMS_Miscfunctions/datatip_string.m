function [tipstr] = datatip_string(obj, event_obj, x, lab)
%DATATIP_STRING     Generate string for display at datatip
%
% John R. Owen, NCRG, 6 Apr 2009
%
%
% obj           Currently unused in matlab
% event_obj     Handle to event object
% x             x(:, 1:2) array of point coords
% lab           Label cas
%
% tipstr        String displayed at datatip


% Get position of datatip
pos = get(event_obj, 'position');

% Use position to index label cas
h1 = (x(:, 1) == pos(1));
h2 = (x(:, 2) == pos(2));
ind = find(h1 & h2);        % Get index to all points at pos           

% Load the tip string
h1 = length(ind);           % How many points at position pos?
if (h1 == 0)                % =0 points found
    tipstr = 'Label Not Found';
elseif (h1 == 1)            % =1 point found
    tipstr = lab{ind};
else                        % >1 point found
    tipstr = blanks(0);
    newline = sprintf('\n');
    for i = 1:h1;
        j = ind(i);
        tipstr = [tipstr, lab{j}, newline];
    end;
end;


