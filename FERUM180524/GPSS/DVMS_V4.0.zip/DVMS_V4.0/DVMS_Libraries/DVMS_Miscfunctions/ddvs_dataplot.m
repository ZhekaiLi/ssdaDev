function ddvs_dataplot(handles, tag, LatTag)
% Plots parallel coordinates 
%  (C) Dharmesh Maniyar,  2006 Adapted from Milva
%  Based on Milva, developed by Davide d'Alimonte

% Make unvisible previously selected points
%   persistent highlighted
  
%   if ishandle(highlighted) & handles.UserData.pattern.button == 1 & get(findobj('Tag','SingleLPC_Btn'),'value')
%     set(highlighted, 'Visible', 'off');
%   end

% tmph.UserData.Data.Id_Values = idsel;
% tmph.UserData.Data.Label_Values = vsel;
% tmph.UserData.Data.Values = datasel;

%   figure
  nsel = size(handles.UserData.Data.Values,1); % Number of selected points
%   if handles.UserData.Config.GetPrediction() == 0 & handles.UserData.Config.GetNo_Variables() ...
%           ~= size(handles.UserData.Data.GetValues(),2)
%       handles.UserData.Data.SetValues([handles.UserData.Data.GetTarget() ...
%                           handles.UserData.Data.GetValues()]);
%   end
  
%   % Color palette for selected data to be highlighted
%   [dat, indall] = sort(dist2([handles.UserData.pattern.X, handles.UserData.pattern.Y], ...
%                              handles.UserData.Model_Object.GetProjected_data()));
%   
%   [row,N] = size(handles.UserData.Data.GetValues());
%   
%   if handles.UserData.DSChartType == 0 % line chart
%     d = dat(1:handles.UserData.pattern.points);
%   else
%     d = dat(1:N)';
%   end
%   ind = indall(1:handles.UserData.pattern.points);
%   d_M = max(d);
%   d_m = min(d);
%   if (d_M  - d_m) < eps
%     d_M = 10;
%   end
%   colind = fix(20-(20-1)*(d_M -d )./(d_M-d_m));
%   colind(colind == 0) = 1;
%   if handles.UserData.pattern.points > 20
%     colind(21:handles.UserData.pattern.points) = 20;
%   end
 
% fp = 0; % Absence of data with fingerprints
  
  % Plotting device according to the feature extraction mode
  switch lower(tag)
    
   case 'pattern'
%        if handles.UserData.Data.GetValues()==0
%            fp = 1;
           data = handles.UserData.Data.Values;
%     data = handles.UserData.Data.GetValues();
    
    %  axes(findobj('Tag', 'PatternExprAxs'));
    DataAxs = findobj('Tag','DataAxs');
    axes(DataAxs);   
    
    xlabel('Variable Index','FontWeight','bold');
    ylabel('Value','FontWeight','bold')

  end
  cla
  
  
  hold on;

  
  % Plot data
%   for j = handles.UserData.pattern.points:-1:1
for j = nsel:-1:1
    
%     PatternLineTag = ['PatternLine' num2str(handles.UserData.pattern.dswindow) num2str(j)];
    PatternLineTag = ['PatternLine' num2str(j)];
    
    if handles.UserData.DSChartType == 0 % line chart
%         d(j)=plot(data(ind(j), :)');
        d(j)=plot(data(j, :)');
%         set(d(j), 'Color', handles.UserData.pal.colall(colind(j), :), ...
%                   'LineWidth', handles.UserData.fig.LineWidth,...
%                   'Tag', PatternLineTag,...
%                   'ButtonDownFcn', ['highlightline ' ...
%                             num2str(handles.UserData.fig.LineWidth) ' ' num2str(handles.UserData.fig.FontGeneInfoSize) ' ' num2str(j) ' ' num2str(handles.UserData.pattern.dswindow)]);
        colind = rem(j,size(handles.UserData.pal.colall,1));
        colind = colind + (colind==0);
        set(d(j), 'Color', handles.UserData.pal.colall(colind, :), ...
                  'LineWidth', handles.UserData.fig.LineWidth,...
                  'Tag', PatternLineTag,...
                  'ButtonDownFcn', ['highlightline ' ...
                            num2str(handles.UserData.fig.LineWidth) ' ' num2str(handles.UserData.fig.FontGeneInfoSize) ' ' num2str(j)]);
    else
%         d(:,j) = data(ind(j),:)';  %bar
        d(:,j) = data(j,:)';  %bar
    end      
      
    if handles.UserData.DSChartType == 1
      bar(d);
    end    
end

  axis tight;
  
  switch lower(tag)
    
   case 'pattern'
%     %  axes(findobj('Tag', 'PatternExprInfoAxs'));	
    axes(findobj('Tag', 'InfosAxs'));
%     resizing the size of InfoAxs based on the selected number of
%        points
       
%        Position_InfoAxs=get(findobj('Tag', 'InfosAxs'),'position');
%        Position_InfoAxs_Pnl=get(findobj('Tag', 'InfosAxs_Pnl'),'position');
%        
%        if nsel >14 
%            set(findobj('Tag', 'InfosAxs_Sld'),'visible','on',...
%                'value',nsel-14,'min',1,'max',nsel-14,...
%                'sliderstep',[1/(nsel-14) 1/((nsel-14)/2)]);  
%        else
%            set(findobj('Tag', 'InfosAxs_Sld'),'visible','off');
%            Position_InfoAxs_Pnl{1}=Position_InfoAxs_Pnl{1}-8;
%        end
%        SinglePointHeight=Position_InfoAxs{4}/10;
%        Position_InfoAxs{2}=Position_InfoAxs{2}-(SinglePointHeight*nsel-SinglePointHeight*10);
%        Position_InfoAxs{4}=SinglePointHeight*nsel;
%        
%        set(findobj('Tag', 'InfosAxs'),'position',Position_InfoAxs);
%        set(findobj('Tag', 'InfosAxs_Pnl'),'position',Position_InfoAxs_Pnl);
%          
%        
%        set(findobj('Tag', 'InfosAxs_Pnl'),'position',Position_InfoAxs_Pnl);
            
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
   case 'feature'
    axes(findobj('Tag', 'LatentVarInfoAxs'));		
    
  end


  % Legend and log info
  v = axis;
  ystep = (v(4)- v(3)) / nsel ;
  xstep = (v(2)- v(1)) / 10;
%   if handles.UserData.pattern.button == 1 | ...
%         handles.UserData.pattern.button == 2 | ...
%         handles.UserData.pattern.button == 110 | ...
%         handles.UserData.pattern.button == 3 | ...          
%         handles.UserData.pattern.button == 32 | ...
%         handles.UserData.pattern.button == 11
    

 
      text(v(2)+2 * xstep-.5, v(4)-((-1)-.25) * ystep, '          ID', ...
           'HorizontalAlignment', 'left', ...
           'VerticalAlignment', 'top', ...
           'Color', [0 0 1],... 
           'FontSize', handles.UserData.fig.FontGeneInfoSize,...
           'Tag', 'PatternHadTag');   
       
       
     for j=1:nsel
          
          % At most 20 records
%           if j < 21
              
              % Plotting coordinates
              yval = [(v(4)-(j-1)*ystep) 
                      (v(4)-((j-1) +.5)*ystep) 
                      (v(4)-((j-1) +.5)*ystep) 
                      (v(4)-(j-1)*ystep)];
              xval = [v(1) v(1) v(2) v(2)];
        
              % Set the format according to the features extraction mode
              if strcmpi(tag, 'features')
%                   ID = handles.UserData.Data.GetId_Values();
                  ID = handles.UserData.Data.Id_Values;
                  info = ID{j}...
                        (1:min(length(ID{j}), 20));
                  error = num2str(handles.UserData.data.ar.err(j), ' [%.4f]');
                  info = [info, error];
              else
%                   ID=handles.UserData.Data.GetId_Values();
                  ID = handles.UserData.Data.Id_Values;
                  info= ID{j}...
                      (1:min(length(ID{j}), 20));
              end   

            % Legend line color and text
            PatternPatchTag = ['PatternPatch' num2str(j)];
            colind = mod(j,21);
            colind = colind + (colind==0);
            h=patch(xval, yval, handles.UserData.pal.colall(colind, :), ...
                    'EdgeColor', handles.UserData.pal.DarkBorder,...
                    'Tag', PatternPatchTag,...
                    'ButtonDownFcn', ['togglelinevisu(' num2str(j) ')']);                
            
            PatternTextTag = ['PatternText' num2str(j)];
            PatternUIcontMenu(j) = uicontextmenu;
%             text(v(2)+2 * xstep, v(4)-((j-1) + .25)* ystep, ['\it{', char(info), '}'], ...
%                  'HorizontalAlignment', 'left', ...
%                  'VerticalAlignment', 'middle', ...
%                  'Color', [0 0 0], 'FontSize', handles.UserData.fig.FontGeneInfoSize, ...
%                  'Tag', PatternTextTag,...
%                  'UIContextMenu',PatternUIcontMenu(j),...
%                  'ButtonDownFcn', ['highlightline ' ...
%                                 num2str(handles.UserData.fig.LineWidth) ' ' ...
%                                 ' ' num2str(handles.UserData.fig.FontGeneInfoSize) ...
%                                 ' ' num2str(j)]);  
             text(v(2)+2 * xstep, v(4)-((j-1) + .25)* ystep, ['\it{', char(info), '}'], ...
                             'HorizontalAlignment', 'left', ...
                             'VerticalAlignment', 'middle', ...
                             'Color', [0 0 0], 'FontSize', handles.UserData.fig.FontGeneInfoSize, ...   
                             'Tag', PatternTextTag,...
                             'UIContextMenu',PatternUIcontMenu(j),...
                             'ButtonDownFcn', ['highlightline ' ...
                                            num2str(handles.UserData.fig.LineWidth) ' ' ...
                                            ' ' num2str(handles.UserData.fig.FontGeneInfoSize) ...
                                            ' ' num2str(j)]);
            
%             if handles.UserData.Config.GetNormalization() ~= 0
%                 scaled_data=data(ind(j),:);
%                 orig_values = rescale(handles.UserData.Data.GetPre_Process(),scaled_data);
%             else
              orig_values = data(j,:);
%             end
%                 for nn=1:length(orig_values)
                for nn=1:size(orig_values,1)
            %        uimenu(PatternUIcontMenu(j),'label',[num2str(nn) ',' num2str(orig_values(nn))]);
                    str=handles.UserData.Data.GetHeader_Str();
                    if ~isempty(str)
                        newname =  regexprep(str{nn}, '_', ' ');
                        uimenu(PatternUIcontMenu(j),'label',[newname ' : ' num2str(orig_values(nn))]);
                    end
                end
          %  else
          %      uimenu(PatternUIcontMenu(j),'label','');
          %  end
            
%       end
      
      % Log info
        
    end
    
%    end
   
   hold on
   % Save eps figure
%    if handles.UserData.pattern.button == 11
%      print('data.eps', '-deps2c')    
%    end
% %   
%   % Visualize latent point corresponding to the selection
%   if strcmp(tag, 'pattern')		
%     if ~sum(strcmp('Visualize_Axes',get(findobj('Tag',LatTag),'tag')))  
%       figure(findobj('Tag', LatTag));
%     else
%       axes(findobj('Tag', LatTag));
%     end
% 
%     for j = nsel:-1:1
%         y=handles.UserData.Model_Object.GetProjected_data();
%         
%       highlighted(j) =  plot(y(ind(j), 1), ...
%                              y(ind(j), 2), 'o');				
%       set(highlighted(j), 'MarkerEdgeColor', handles.UserData.pal.DarkBorder);
%       set(highlighted(j), 'MarkerFaceColor', handles.UserData.pal.colall(colind(j), :));
%       set(highlighted(j), 'MarkerSize', handles.UserData.fig.SelectedMarkerSize);    
%     end
% 
% %     highlighted(nsel+1) = text(handles.UserData.pattern.X, handles.UserData.pattern.Y, num2str(handles.UserData.pattern.dswindow), 'FontWeight', 'Bold',...
% %                  'FontSize', 14, 'Color', 'w',...
% %                  'HorizontalAlignment', 'center');
%              
%     
% 
%   end
  
