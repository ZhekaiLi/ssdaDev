function  VisualiseSalienciesPlot(obs)
x1= 1:length(obs.Estftwt);
h1=stem(x1,obs.Estftwt);
set(h1,'color','b');
set(h1,'markerfacecolor','b');
h1=xlabel('Feature No.','FontSize',10);
h1=ylabel('Feature Saliency (Estimated)','FontSize',10);
set(gca,'XLim',[0 size(x1,2)+1]);
set(gca,'YLim',[0 1.01]);
set(gca,'XTick',[0:1:size(x1,2)]);
set(gca,'YTick',[0:0.1:1]);
end