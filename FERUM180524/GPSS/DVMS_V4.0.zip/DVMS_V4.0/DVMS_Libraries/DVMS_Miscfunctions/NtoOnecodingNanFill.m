function Coded = NtoOnecodingNanFill( Data,start_inds,end_inds )
%ONETONCODING Summary of this function goes here
%   Detailed explanation goes here
Coded=zeros(size(Data,1),size(start_inds,2));
for j=1:1:size(start_inds,2)
    for i=1:1:size(Data,1)
        singlefeature=sum(isnan(Data(i,start_inds(j):end_inds(j))));
        if singlefeature ~=0
            Coded(i,j)=NaN;
        end
        clear singlefeature
    end
end
end

