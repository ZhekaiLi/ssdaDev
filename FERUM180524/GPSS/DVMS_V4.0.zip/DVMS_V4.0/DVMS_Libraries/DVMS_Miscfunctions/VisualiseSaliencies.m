

function VisualiseSaliencies(input)

figure

if isstruct(input)
    Num_Sub_Models = size(input.obs_array,2);
    placey = 1;
    placex = Num_Sub_Models;
    if     placex >= 4 && placex <= 6
           placex = ceil(placex/2);
           placey = 2;
    elseif placex > 6 && placex <= 12
           placex = ceil(placex/3);
           placey = 3;
    elseif placex > 12
           placex = ceil(placex/4);
           placey = 4;
    end    
    whitebg(gcf,'w');
    for SM = 1:Num_Sub_Models    
        ax=subplot(placey, placex, SM);
        obs=input.obs_array{SM};
        VisualiseSalienciesPlot(obs);
        axis('square');        
        set(gca, 'Box', 'On')
        if strcmp(obs.type,'continuous')        
             TYPE='Continuous';
        else
            if strcmp(obs.type,'discrete')
                switch obs.dist_type
                    case 'bernoulli'
                        TYPE='Binary';
                    case 'multinomial'
                        TYPE='Multinomial';                   
                end           
            end
        end
        t_ = sprintf('Observation Type %s: %s', num2str(SM),TYPE);
        title(t_, 'FontSize', 10);
    end  
else
    y=input;
    x= 1:length(y);
    h1=stem(x,y);
    set(h1,'color','b');
    set(h1,'markerfacecolor','b');
    h1=title('GTM-FS Feature Saliencies');
    set(h1,'fontsize',12);
    h1=xlabel('Feature No.');
    set(h1,'fontsize',10);
    h1=ylabel('Feature Saliency (Estimated)');
    set(h1,'fontsize',10);
    set(gca,'XLim',[0 size(x,2)+1]);
    set(gca,'YLim',[0 1.01]);
    set(gca,'XTick',[0:1:size(x,2)]);
    set(gca,'YTick',[0:0.1:1]);
end

