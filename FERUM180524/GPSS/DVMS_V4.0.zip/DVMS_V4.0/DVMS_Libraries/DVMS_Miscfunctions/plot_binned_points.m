function Visualize = plot_binned_points(x, t, binlim,tn)
%PLOT_BINNED_POINTS   Plot Binned Points
%
% Bin points according to bin-limits and plot the points
%
% John R. Owen, NCRG, 8 Mar 2009
%


% Easy-access local parameters
% % % % % % % % % % % %binlim = fparam.binlim;
% % % % % Commented for the time being to fix the name of the target Shahzad Mumtaz
% % % % tn = fparam.targetname;

% Set axes to main plot axes
ax1 = findobj('tag', 'Visualize_Axes');
if (gca ~= ax1)
    set(gcf, 'currentaxes', ax1);
end;
cla;    % Clear main axes

% Parameterise points to plot
nmstyle = 5;                        % No. of marker styles
marker = blanks(nmstyle);           % Marker type
msize = zeros(nmstyle, 1);          % Marker size
clr = zeros(nmstyle, 3);            % Marker colour
mfclr = zeros(nmstyle, 3);          % Marker face colour

% Load marker types
marker(1) = 'o';
marker(2) = 'o';
marker(3) = 'o';
marker(4) = 'o';
marker(5) = 's';

% Load marker sizes
msize(:, 1) = 3;

% Load marker colours
clr(1, :) = [1, 0, 0];                  % Red
clr(2, :) = [0, 0, 0];                  % Black
clr(3, :) = [0.000, 0.784, 0.784];      % Light blue
clr(4, :) = [0, 1, 0];                  % Green
clr(5, :) = [0, 0, 0];                  % Black (border)

% Load marker face colours
for i = 1:nmstyle;
    mfclr(i, :) = clr(i, :);
end;
% Yellow face colour for outside range
mfclr(5, :) = [1.000, 0.862, 0.000];



% -------------------
% Generate the legend
% -------------------

% Force onscreen position of legend by plotting it over small axes
% Set and make invisible small axes
ax2 = findobj('tag', 'Legend_Axes');
if (gca ~= ax2)
    set(gcf, 'currentaxes', ax2);
end;
cla;



% Hold ready to plot
hold on;

% Plot points to init. legend
for i = 1:nmstyle;
    h1 = plot(0, 0, 'd');
    set(h1, 'marker', marker(i));
    set(h1, 'markersize', msize(i));
    set(h1, 'color', clr(i, :));
    set(h1, 'markerfacecolor', mfclr(i, :));
end;

% Set background colour of small axes to the system background colour
backclr = get(gcf, 'color');
set(ax2, 'color', backclr);

% Delete points by plotting over them in background colour
for i = 1:nmstyle;
    h1 = plot(0, 0, 'd');
    set(h1, 'marker', marker(i));
    set(h1, 'markersize', msize(i));
    set(h1, 'color', backclr);
    set(h1, 'markerfacecolor', backclr);
end;



% -----------
% Plot legend
% -----------

% One cell for each line in legend
str1 = cell(nmstyle, 1);

t1 = num2str(binlim(1));
t2 = num2str(binlim(2));
t3 = num2str(binlim(3));
t4 = num2str(binlim(4));
t5 = num2str(binlim(5));

%str1{1} = [tn, ': ', t1, ' - ', t2];
kk=sprintf([tn, ':\n ', t1, ' - ', t2]);
str1{1}=[kk];
%str1{2} = [tn, ': ', t2, ' - ', t3];
kk=sprintf([tn, ':\n ', t2, ' - ', t3]);
str1{2}=[kk];
%str1{3} = [tn, ': ', t3, ' - ', t4];
kk=sprintf([tn, ':\n ', t3, ' - ', t4]);
str1{3}=[kk];
%str1{4} = [tn, ': ', t4, ' - ', t5];
kk=sprintf([tn, ':\n ', t4, ' - ', t5]);
str1{4}=[kk];
%str1{5} = [tn, ': Outside Limits'];
kk=sprintf([tn, ':\n Outside Limits']);
str1{5}=[kk];



axis('square');
set(gca, 'Box', 'Off')
%set(gca, 'ytick', [], 'xtick', []);
legboxcol = [0.51 0.51 0.51];
set(gca,'XColor',legboxcol);
set(gca,'YColor',legboxcol);
set(gca,'Color',legboxcol);
  
  
  
  

h1 = legend(ax2, str1);

%added to be used in the print on visualize axes
Visualize.legend=h1;
Visualize.displayaxes=ax1;
% Set background colour of legend to white
%set(h1, 'color', [1, 1, 1]);
% Generate the plot's legend
  set(h1, 'TextColor', 'k');
  set(h1, 'Location', 'north');
  set(h1, 'Interpreter', 'none');
  set(ax2,'visible','off')



% --------------------
% Plot the data points
% --------------------

% Put each point into a bin depending on its activity/target value
lenx = length(x);
ptc = zeros(lenx, 1);   % Bin for each point  

% Local variables to hold bin-limits
t1 = binlim(1);
t2 = binlim(2);
t3 = binlim(3);
t4 = binlim(4);
t5 = binlim(5);

% Bin each point by its activity value
for i = 1:lenx;
    h1 = t(i);
    if ((h1 > t1) || (h1 < t5))
        ptc(i) = 5;         % Outside bin-limits
    elseif (h1 >= t2)
        ptc(i) = 1;         % Bin 1
    elseif (h1 >= t3)
        ptc(i) = 2;         % Bin 2
    elseif (h1 >= t4)
        ptc(i) = 3;         % Bin 3
    else
        ptc(i) = 4;         % Otherwise bin 4
    end;
end;


% Set axes to main plot axes
if (gca ~= ax1)
    set(gcf, 'currentaxes', ax1);
end;
cla;

% Hold all points on the plot
hold on;



% ---------------
% Plot the points
% ---------------

% Plot most active last ensuring these are always plotted
% on top of all other points

for i = nmstyle:-1:1;
    for j = 1:lenx;
        h1 = ptc(j);
        if (h1 == i)
            h2 = plot(x(j, 1), x(j, 2), 'd');
            set(h2, 'marker', marker(h1), 'markersize', msize(h1));
            set(h2, 'color', clr(h1, :), 'markerfacecolor', mfclr(h1, :));
        end;
    end;    
end;
legboxcol = [1 1 1];
set(gca,'XColor',legboxcol);
set(gca,'YColor',legboxcol);
set(gca,'Color',legboxcol);
axis('square');
set(gca, 'Box', 'On')
%set(gca, 'ytick', [], 'xtick', []);
hold on;

drawnow;





