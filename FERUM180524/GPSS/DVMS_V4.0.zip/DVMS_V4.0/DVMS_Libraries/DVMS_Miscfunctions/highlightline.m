function highlightline(LineWidth,FontGeneInfoSize,TheLine)
% To highlight selected pattern in the dataspace visualistion
%  (C) Dharmesh Maniyar,  2006

disp ('in highlightline');
if str2num(LineWidth) == 999 % nasty hack for compiling as stand alone applciation
    return;
else
    
    PatterLineTag = ['PatternLine', TheLine];
    PatterTextTag = ['PatternText', TheLine];
    
    % Get current plotting line width value
    HLineWidth = get(findobj('Tag', PatterLineTag), 'LineWidth');
    if iscell(HLineWidth)
        LineWidth1 = cell2num(HLineWidth(1));
        LineWidth2 = cell2num(HLineWidth(2));
    else
        LineWidth1 = HLineWidth;
    end
    %  mydebug2(['The line: ',PatterTextTag,' hlinewidth ',HLineWidth,' LineWidth ',LineWidth]);
    % Switch line width and highlight text
    if  HLineWidth == str2num(LineWidth)
        set(findobj('Tag', PatterLineTag), 'LineWidth', 3 * ...
            str2num(LineWidth));
        
        set(findobj('Tag', PatterTextTag), 'FontSize', ...
            1.5 * str2num(FontGeneInfoSize),...
            'Color', [1 0 0]);
    else
        set(findobj('Tag', PatterLineTag), 'LineWidth', ...
            str2num(LineWidth));
        
        set(findobj('Tag', PatterTextTag), 'FontSize', ...
            str2num(FontGeneInfoSize),...
            'Color', [0 0 0]);
    end
end