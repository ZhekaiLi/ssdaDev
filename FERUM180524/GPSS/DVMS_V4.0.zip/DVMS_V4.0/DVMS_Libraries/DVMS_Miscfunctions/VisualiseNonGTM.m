function  VisualiseNonGTM( Y,Label,LabelType,binlim )
%VISUALISE Summary of this function goes here
%   Detailed explanation goes here
Label_Object=Labels_Cls();
if strcmp(LabelType,'Discrete')
    [infoSort, ind] = sortrows(Label,size(Label,2));
    
    lableSort = Y(ind,:);
    for nn = 1:size(lableSort,1)
        h = plot(lableSort(nn,1),lableSort(nn,2),'.');
        set(h,'Color',Label_Object.GetCol(infoSort(nn)),'Marker',Label_Object.GetMarker(infoSort(nn)),'Hittest','on');
        set(h,'LineWidth',2);
        set(h,'markersize',9);
        hold on        
    end
    
    %axis([-1.06, 1.06, -1.06, 1.06]);
else
    % Plot using plot_binned_points.
    
    if strcmp(LabelType,'Continuous')
        
        y1 = Y;
        t1 = Label;
        tn='TargetMixed';
        % Call main fprint plotting code
        visualize=plot_binned_points(y1, t1, binlim,tn);
    else
        h =  plot(y(:, 1), ...
            y(:, 2), '.','Hittest','on');
        set(handles.Legend_Axes,'visible','off')
    end
end
set(gca,'ydir','normal')
set(gca,'ytick',[],'xtick',[]);
end

