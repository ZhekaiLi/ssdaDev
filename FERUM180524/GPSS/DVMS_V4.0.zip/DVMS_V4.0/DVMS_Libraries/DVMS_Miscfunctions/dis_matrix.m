function [dm] = dis_matrix(x, f, disparam)
%DIS_MATRIX     Compute distance matrix of descriptor and fingerprint data
%
% x = ddata
% f = fdata
% disparam = distance calculation parameters
% NB: This routine assumes fdata is always present. ddata can be absent (= []).
%
% John R. Owen, NCRG, 18 May 2009
%

% Load distance matrix parameters
gammad = disparam.gammad;
gammaf = disparam.gammaf;
disd = disparam.disd;
disf = disparam.disf;
nr = size(f, 1);                    % No. rows from fdata (always present)
dm = zeros(nr, nr);                 % Init. distance matrix

% Set flags to indicate presence/absence of ddata
if (isempty(x))                 
    xpresent = false;
else
    xpresent = true;
end;

% Set up waitbar
wb1 = waitbar(0, 'Computing distance matrix.....');
set(wb1, 'name', 'Wait');
% Change waitbar bar-colour to green (default is red)
h1 = findobj(wb1, 'Type', 'Patch');
set(h1, 'edgecolor', 'g');
set(h1, 'facecolor', 'g');

% Note: dm matrix is symmetrical, hence j index starts from i (not 1!)
for i = 1:nr;
    for j = i:nr;
        if (xpresent)           % Compute ddata distance
            h1 = x(i, :);
            h2 = x(j, :);
            d1 = gammad * mol_dis(h1, h2, disd);
        else
            d1 = 0;
        end;
        
        h1 = f(i, :);           % Compute fdata distance
        h2 = f(j, :);
        d2 = gammaf * mol_dis(h1, h2, disf);
        
        dm(i, j) = d1 + d2;     % Compute total distance
    end;
    waitbar(i/nr);
end;
close(wb1);
drawnow;

% Finally complete dm by symmetry
dm = dm + (dm');



