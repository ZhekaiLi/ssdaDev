function [] = copy_clipboard_fdata(ind,y, conf, data)

newline = sprintf('\n');
nline = length(ind);
format = '%15.6e';

% Does 4th column exist to copy? Load 4th column parameters.
if (conf.GetTarget_ColIndx()) 
    fourth = true;
    hcol = data.GetTarget_Values();
    str1 = ['ID, X-Latent, Y-Latent, Target', newline];
elseif (conf.GetNo_Labels()>0)
    fourth = true;
    hcol = data.GetLabel_Values();
    str1 = ['ID, X-Latent, Y-Latent, Label', newline];
else
    % No 4th column required
    fourth = false;
    h1 = length(data.GetLabel_Values());
    hcol = -9999 * ones(h1, 1);
    str1 = ['ID, X-Latent, Y-Latent', newline];
end;

% Concatenate all lines into one large string
id=data.GetId_Values();

for i = 1:nline;
    j = ind(i);
    h1 = id{j};
    h2 = num2str(y(j, 1), format);
    h3 = num2str(y(j, 2), format);
    h4 = num2str(hcol(j), format);
    if (fourth)
        str1 = [str1, h1, ', ', h2, ', ', h3, ', ', h4, newline];
    else
        str1 = [str1, h1, ', ', h2, ', ', h3, newline];
    end;
end;

% Finally copy the large string to clipboard
clipboard('copy', str1);
fprintf('\nClipboard: %4.0f points copied\n', nline);
end