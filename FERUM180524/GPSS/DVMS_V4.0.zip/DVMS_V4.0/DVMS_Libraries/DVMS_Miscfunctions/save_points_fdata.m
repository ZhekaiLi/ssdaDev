% --------------------------------------------------------
% Save latent-space points to file when fdata only present
% --------------------------------------------------------

function [] = save_points_fdata(y,conf, data)

str1 = 'Save: enter filename (include .csv extension)';
[filename, pathname] = uiputfile({'.csv'}, str1);
if (isnumeric(pathname))
    fprintf('\nFile not saved.\n');
    return;
end;

holdpath = pwd;
cd(pathname);
fid = fopen(filename, 'w');

newline = sprintf('\n');
nline = length(data.GetId_Values());
format = '%15.6e';

% Does 4th column exist to save? Load 4th column parameters.
if (conf.Target_ColIndx()) 
    fourth = true;
    hcol = data.GetTarget_Values();
    str1 = ['ID, X-Latent, Y-Latent, Target', newline];
elseif (conf.GetNo_Labels)
    fourth = true;
    hcol = data.GetLabel_Values();
    str1 = ['ID, X-Latent, Y-Latent, Label', newline];
else
    % No 4th column required
    fourth = false;
    h1 = length(data.GetLabel_Values());
    hcol = -9999 * ones(h1, 1);
    str1 = ['ID, X-Latent, Y-Latent', newline];
end;

fprintf('\nSaving all points.....\n');
% Write the header
fprintf(fid, '%s', str1);


% Write to file line-by-line
id=data.GetId_Values();
for i = 1:nline;
    h1 = id{i};
    h2 = num2str(y(i, 1), format);
    h3 = num2str(y(i, 2), format);
    h4 = num2str(hcol(i), format);
    if (fourth)
        str1 = [h1, ', ', h2, ', ', h3, ', ', h4, newline];
    else
        str1 = [h1, ', ', h2, ', ', h3, newline];
    end;
    
    % Write line-by-line
    fprintf(fid, '%s', str1);
end;

fclose(fid);
fprintf('Save to file %s complete.\n', filename);

% Return to original directory
cd(holdpath);
end