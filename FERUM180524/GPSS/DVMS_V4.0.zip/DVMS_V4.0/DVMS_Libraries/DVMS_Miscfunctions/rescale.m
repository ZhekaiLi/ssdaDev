function x = rescale(preproc, y)
% RESCALE Applies rescaling linear transformation

% Copyright (c) Ian T Nabney 2000

if isfield(preproc, 'mu') & ~isempty(preproc.mu)
  % Rescale data, taking care over columns with zero variance to avoid
  % division by zero
  e = ones(size(y, 1), 1);
  x = y .* (e*preproc.sigma) + (e * preproc.mu); 
  %  y = (x - e*preproc.mu)./(e*(preproc.sigma+(preproc.sigma==0)));
else
  % Do nothing
  x = y;
end