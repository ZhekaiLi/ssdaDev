function g = robTwoDynamicsLogLikeGradients(model)

% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
%
%	Description:
%	g = robTwoDynamicsLogLikeGradients(model)
%% 	robTwoDynamicsLogLikeGradients.m CVS version 1.3
% 	robTwoDynamicsLogLikeGradients.m SVN version 29
% 	last update 2007-11-03T14:32:30.000000Z

g = [];