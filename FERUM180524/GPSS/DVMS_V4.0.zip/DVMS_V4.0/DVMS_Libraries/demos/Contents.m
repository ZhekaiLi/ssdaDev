% NetLab Neural Network Library
% Version I1.1  21-Jan-96.
% Copyright (c)  Christopher M Bishop (1996).
%
% Regression.
% regress1 - simple 1-input 1-output noisy interpolation with feed-forward net.
%
% Bayesian methods.
% bayes1 - bayesian regression with hyperparameter re-estmation and error bars.
% hmc_dem2 - hybrid Monte Carlo for a simple regression problem.
