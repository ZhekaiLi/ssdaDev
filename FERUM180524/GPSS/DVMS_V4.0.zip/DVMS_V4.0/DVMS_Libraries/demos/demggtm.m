%DEMGGTM Demonstrates the GGTM with a mixture of continuous, binary
%and multinomial data.

addpath ..\netlab
addpath ..\DVMS_Miscfunctions
addpath ..\utilities
addpath ..\..\DVMS_Classes

clear all
clc

% Fix seeds for reproducible results
reset_random(12);

% GGTM architecture
dim_latent = 2;
latent_shape = [8 8];  % Number of latent points in each dimension
nlatent = prod(latent_shape);  % Number of latent points
rbf_grid = [4 4];
num_rbf_centres = prod(rbf_grid);
rbf_prior = 0.01;
samp_type = 'regular';

% Mapping function 
map.type = 'rbf';
map.func = 'gaussian';
map.ncentres = num_rbf_centres;
map.prior = rbf_prior;


% ----------------
% Continuous data
% ----------------
load ..\..\ExampleDataSets\SyntheticDataset\cont_train_data
cont_data = cont_train_data;
labels = cont_data(:,end);
cont_data(:,end) = []; % Remonve label info
[pre, cdata.mat] = normal(cont_data); 
cdata.type = 'continuous';
cdata.nvar = size(cdata.mat,2);

% Mixture model
cmix.type = 'gmm';
cmix.covar_type = 'spherical';

% ------------
% Binary data
% ------------
load ..\..\ExampleDataSets\SyntheticDataset\bin_train_data
bdata.mat = bin_train_data;
bdata.mat(:,end) = []; % Remonve label info
bdata.type = 'discrete';
bdata.nvar = size(bdata.mat,2);

% Mixture model
bmix.type = 'dmm';
bmix.covar_type = 'spherical';
bmix.dist_type = 'bernoulli';
bmix.cat_nvals = 2;

% -----------------
% Multinomial data
% -----------------
load ..\..\ExampleDataSets\SyntheticDataset\mult_train_data
tmp_mdata = mult_train_data;
tmp_mdata(:,end) = []; % Remonve label info
[mdata.mat, mdata.cat_nvals] = OnetoNcoding(tmp_mdata); 
mdata.start_inds = [1, cumsum(mdata.cat_nvals(1,end-1))+1];
mdata.end_inds = cumsum(mdata.cat_nvals);
mdata.type = 'discrete';
mdata.nvar = size(mdata.mat,2);

% Mixture model
mmix.type = 'dmm';
mmix.covar_type = 'spherical';
mmix.dist_type = 'multinomial';
mmix.cat_nvals = mdata.cat_nvals;

% -----------
% Mixed data
% -----------

% Data array (one or more of the following 3 lines can be removed if one
% is interested in a particular combination of data. The indices of
% DATA_ARRAY array would need to be changed accordingly.)
data_array{1} = cdata;
data_array{2} = bdata;
data_array{3} = mdata;

ndata = size(data_array,2);
dim_data_array = zeros(1,ndata);
for i=1:ndata
    dim_data_array(i) = data_array{i}.nvar;
end

% Mixture models array (one or more of the following 3 lines can be removed
% if one is interested in a particular combination of data. The indices of
% MIX_ARRAY array would need to be changed accordingly.)
mix_array{1} = cmix;
mix_array{2} = bmix;
mix_array{3} = mmix;

% Create and initialise GTM model
net = ggtm(dim_latent, nlatent, dim_data_array, map, mix_array);

options = foptions;
options(1) = 1; % This provides display of error values
options(3) = 1.0e-4; % Tolerance in value of function
options(7) = 1;    % Set width factor of RBF

net = ggtminit(net, options, data_array, samp_type, latent_shape,rbf_grid);

[net, options] = ggtmem(net, data_array, options);

% Posterior means
means = ggtmlmean(net, data_array);
Visualise(means,labels,'Discrete')

