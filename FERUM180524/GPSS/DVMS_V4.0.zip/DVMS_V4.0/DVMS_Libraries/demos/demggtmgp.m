%DEMGGTM Demonstrates the GGTM with a mixture of continuous, binary
%and multinomial data. It should be noted that the GP mapping only works
%with continuous data at the moment.

addpath ..\netlab
addpath ..\DVMS_Miscfunctions
addpath ..\utilities
addpath ..\..\DVMS_Classes

clear all
clc

% Fix seeds for reproducible results
reset_random(12);

% GGTM architecture
dim_latent = 2;
latent_shape = [8 8];  % Number of latent points in each dimension
nlatent = prod(latent_shape);  % Number of latent points
samp_type = 'gaussian';

% Mapping function 
map.type = 'gp';
map.func = 'sqexp';


% ----------------
% Continuous data
% ----------------
load ..\..\ExampleDataSets\SyntheticDataset\cont_train_data
cont_data = cont_train_data;
labels = cont_data(:,end);
cont_data(:,end) = []; % Remonve label info
[pre, cdata.mat] = normal(cont_data); 
cdata.type = 'continuous';
cdata.nvar = size(cdata.mat,2);

% Mixture model
cmix.type = 'gmm';
cmix.covar_type = 'spherical';

% Data array 
data_array{1} = cdata;

ndata = size(data_array,2);
dim_data_array = zeros(1,ndata);
for i=1:ndata
    dim_data_array(i) = data_array{i}.nvar;
end

% Mixture models array
mix_array{1} = cmix;

% Create and initialise GTM model
net = ggtm(dim_latent, nlatent, dim_data_array, map, mix_array);

options = foptions;
options(1) = 1; % This provides display of error values
options(3) = 1.0e-4; % Tolerance in value of function
options(7) = 1;    % Set width factor of RBF
options(13)= 0.1; % Alpha
options(15)= 0.1; % Nu
options(16)= 0.1; % Lambda

net = ggtminit(net, options, data_array, samp_type, latent_shape);

[net, options, errlog] = ggtmem(net, data_array, options);

% Posterior means
means = ggtmlmean(net, data_array);
Visualise(means,labels,'Discrete')

