function g = rosegrad(x)

% Return gradient of Rosenbrock's test function

nrows = size(x, 1);
g = zeros(nrows,2);

g(:,1) = -400 * (x(:,2) - x(:,1).^2) * x(:,1) - 2 * (1 - x(:,1));
g(:,2) = 200 * (x(:,2) - x(:,1).^2);
